/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import Controller.ControllerMakanan;
import javax.swing.*;

/**
 *
 * @author Asus
 */

public class InputMakanan extends JFrame {

    ControllerMakanan controller;

    JLabel title =
            new JLabel("INPUT MAKANAN");

    JLabel lbNama =
            new JLabel("Nama Makanan");

    JLabel lbKalori =
            new JLabel("Kalori");

    JLabel lbProtein =
            new JLabel("Protein");

    JLabel lbKarbo =
            new JLabel("Karbohidrat");

    JLabel lbLemak =
            new JLabel("Lemak");

    JTextField tfNama =
            new JTextField();

    JTextField tfKalori =
            new JTextField();

    JTextField tfProtein =
            new JTextField();

    JTextField tfKarbo =
            new JTextField();

    JTextField tfLemak =
            new JTextField();

    JButton btnSimpan =
            new JButton("Simpan");

    JButton btnBack =
            new JButton("Back");

    public InputMakanan() {

        controller =
                new ControllerMakanan();

        setTitle("Input Makanan");

        setSize(400, 450);

        setLayout(null);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= TITLE =================

        title.setBounds(120, 20, 200, 30);

        // ================= LABEL =================

        lbNama.setBounds(30, 80, 120, 25);

        lbKalori.setBounds(30, 130, 120, 25);

        lbProtein.setBounds(30, 180, 120, 25);

        lbKarbo.setBounds(30, 230, 120, 25);

        lbLemak.setBounds(30, 280, 120, 25);

        // ================= TEXTFIELD =================

        tfNama.setBounds(150, 80, 180, 25);

        tfKalori.setBounds(150, 130, 180, 25);

        tfProtein.setBounds(150, 180, 180, 25);

        tfKarbo.setBounds(150, 230, 180, 25);

        tfLemak.setBounds(150, 280, 180, 25);

        // ================= BUTTON =================

        btnSimpan.setBounds(50, 340, 120, 40);

        btnBack.setBounds(200, 340, 120, 40);

        // ================= ADD =================

        add(title);

        add(lbNama);
        add(lbKalori);
        add(lbProtein);
        add(lbKarbo);
        add(lbLemak);

        add(tfNama);
        add(tfKalori);
        add(tfProtein);
        add(tfKarbo);
        add(tfLemak);

        add(btnSimpan);
        add(btnBack);

        // ================= ACTION SIMPAN =================

        btnSimpan.addActionListener(e -> {

            try {

                boolean berhasil =
                        controller.insertMakanan(
                                getNamaMakanan(),
                                getKalori(),
                                getProtein(),
                                getKarbohidrat(),
                                getLemak());

                if (berhasil) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Data berhasil disimpan!");

                    new ViewMakanan();

                    dispose();

                } else {

                    JOptionPane.showMessageDialog(
                            null,
                            "Data gagal disimpan!");
                }

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Input harus angka!");
            }
        });

        // ================= ACTION BACK =================

        btnBack.addActionListener(e -> {

            new ViewMakanan();

            dispose();
        });

        setVisible(true);
    }

    // ================= GETTER =================

    public String getNamaMakanan() {

        return tfNama.getText();
    }

    public double getKalori() {

        return Double.parseDouble(
                tfKalori.getText());
    }

    public double getProtein() {

        return Double.parseDouble(
                tfProtein.getText());
    }

    public double getKarbohidrat() {

        return Double.parseDouble(
                tfKarbo.getText());
    }

    public double getLemak() {

        return Double.parseDouble(
                tfLemak.getText());
    }

    public JButton getBtnSimpan() {

        return btnSimpan;
    }

    public JButton getBtnBack() {

        return btnBack;
    }
}