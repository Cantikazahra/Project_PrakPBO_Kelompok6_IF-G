/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import Controller.ControllerMakanan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class InputMakanan extends JDialog {

    private ControllerMakanan controller;
    private boolean dataTersimpan = false;

    JTextField tfNama = new JTextField();
    JTextField tfKalori = new JTextField();
    JTextField tfProtein = new JTextField();
    JTextField tfKarbo = new JTextField();
    JTextField tfLemak = new JTextField();

    JButton btnSimpan = new JButton("Simpan");
    JButton btnBatal = new JButton("Batal");

    public InputMakanan(JFrame parent) {

        super(parent, "Tambah Data Makanan", true);

        controller = new ControllerMakanan();

        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBackground(Color.WHITE);
        content.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("TAMBAH DATA MAKANAN", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(33, 150, 243));
        content.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        String[] labels = {"Nama Makanan", "Kalori", "Protein (g)", "Karbohidrat (g)", "Lemak (g)"};
        JTextField[] fields = {tfNama, tfKalori, tfProtein, tfKarbo, tfLemak};

        for (int i = 0; i < labels.length; i++) {
            JLabel lb = new JLabel(labels[i]);
            lb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            fields[i].setPreferredSize(new Dimension(220, 35));
            fields[i].setFont(new Font("Segoe UI", Font.PLAIN, 13));

            gbc.gridx = 0; gbc.gridy = i;
            form.add(lb, gbc);
            gbc.gridx = 1;
            form.add(fields[i], gbc);
        }

        content.add(form, BorderLayout.CENTER);

        styleBtn(btnSimpan, new Color(76, 175, 80));
        styleBtn(btnBatal,  new Color(120, 120, 120));
        btnSimpan.setPreferredSize(new Dimension(130, 40));
        btnBatal.setPreferredSize(new Dimension(130, 40));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setBackground(Color.WHITE);
        btnPanel.add(btnSimpan);
        btnPanel.add(btnBatal);
        content.add(btnPanel, BorderLayout.SOUTH);

        add(content);

        btnSimpan.addActionListener(e -> {
            try {
                String nama    = tfNama.getText().trim();
                double kalori  = Double.parseDouble(tfKalori.getText().trim());
                double protein = Double.parseDouble(tfProtein.getText().trim());
                double karbo   = Double.parseDouble(tfKarbo.getText().trim());
                double lemak   = Double.parseDouble(tfLemak.getText().trim());

                if (nama.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Nama makanan tidak boleh kosong!");
                    return;
                }

                boolean sukses = controller.insertMakanan(nama, kalori, protein, karbo, lemak);
                if (sukses) {
                    JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
                    dataTersimpan = true;
                    dispose();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Input angka tidak valid!");
            }
        });

        btnBatal.addActionListener(e -> dispose());

        pack();
        setLocationRelativeTo(parent);
        setVisible(true);
    }

    public boolean isDataTersimpan() {
        return dataTersimpan;
    }

    private void styleBtn(JButton b, Color c) {
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
    }
}