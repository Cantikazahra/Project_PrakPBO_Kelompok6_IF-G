/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import Controller.ControllerKonsumsi;
import Model.DataMakanan.Makanan;
import Model.Konsumsi.Konsumsi;
import Model.Users.Member;
import View.Dashboard.DashboardMember;

import java.sql.Date;
import java.util.List;
import javax.swing.*;

/**
 *
 * @author Asus
 */

public class KonsumsiMakanan extends JFrame {

    // ================= COMPONENT =================

    JLabel title =
            new JLabel("KONSUMSI MAKANAN");

    // SEARCH
    JLabel lbCari =
            new JLabel("Cari Makanan");

    JTextField tfCari =
            new JTextField();

    JButton btnCari =
            new JButton("Cari");

    // PILIH MAKANAN
    JLabel lbMakanan =
            new JLabel("Pilih Makanan");

    JComboBox<String> cbMakanan =
            new JComboBox<>();

    // GRAM
    JLabel lbGram =
            new JLabel("Jumlah Gram");

    JTextField tfGram =
            new JTextField();

    // HASIL
    JLabel lbHasilMakanan =
            new JLabel("Makanan");

    JLabel lbKalori =
            new JLabel("Total Kalori");

    JLabel lbProtein =
            new JLabel("Total Protein");

    JLabel lbKarbo =
            new JLabel("Total Karbohidrat");

    JLabel lbLemak =
            new JLabel("Total Lemak");

    JLabel hasilMakanan =
            new JLabel("-");

    JLabel hasilKalori =
            new JLabel("0 kcal");

    JLabel hasilProtein =
            new JLabel("0 g");

    JLabel hasilKarbo =
            new JLabel("0 g");

    JLabel hasilLemak =
            new JLabel("0 g");

    // BUTTON
    JButton btnHitung =
            new JButton("Hitung");

    JButton btnSimpan =
            new JButton("Simpan");

    JButton btnBack =
            new JButton("Back");

    // ================= DATA =================

    List<Makanan> listMakanan;

    Member member;

    ControllerKonsumsi controller =
            new ControllerKonsumsi();

    // ================= CONSTRUCTOR =================

    public KonsumsiMakanan(
            List<Makanan> listMakanan,
            Member member) {

        this.listMakanan = listMakanan;

        this.member = member;

        setTitle("Konsumsi Makanan");

        setSize(550, 650);

        setLayout(null);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= TITLE =================

        title.setBounds(
                150,
                20,
                300,
                30);

        // ================= SEARCH =================

        lbCari.setBounds(
                40,
                80,
                120,
                25);

        tfCari.setBounds(
                180,
                80,
                220,
                30);

        btnCari.setBounds(
                410,
                80,
                80,
                30);

        // ================= PILIH MAKANAN =================

        lbMakanan.setBounds(
                40,
                140,
                120,
                25);

        cbMakanan.setBounds(
                180,
                140,
                220,
                30);

        for (Makanan makanan : listMakanan) {

            cbMakanan.addItem(
                    makanan.getNama_makanan());
        }

        // ================= GRAM =================

        lbGram.setBounds(
                40,
                200,
                120,
                25);

        tfGram.setBounds(
                180,
                200,
                220,
                30);

        // ================= BUTTON =================

        btnHitung.setBounds(
                60,
                260,
                120,
                35);

        btnSimpan.setBounds(
                200,
                260,
                120,
                35);

        btnBack.setBounds(
                340,
                260,
                120,
                35);

        // ================= HASIL =================

        lbHasilMakanan.setBounds(
                40,
                340,
                150,
                25);

        hasilMakanan.setBounds(
                240,
                340,
                200,
                25);

        lbKalori.setBounds(
                40,
                390,
                150,
                25);

        hasilKalori.setBounds(
                240,
                390,
                200,
                25);

        lbProtein.setBounds(
                40,
                430,
                150,
                25);

        hasilProtein.setBounds(
                240,
                430,
                200,
                25);

        lbKarbo.setBounds(
                40,
                470,
                150,
                25);

        hasilKarbo.setBounds(
                240,
                470,
                200,
                25);

        lbLemak.setBounds(
                40,
                510,
                150,
                25);

        hasilLemak.setBounds(
                240,
                510,
                200,
                25);

        // ================= ADD =================

        add(title);

        add(lbCari);
        add(tfCari);
        add(btnCari);

        add(lbMakanan);
        add(cbMakanan);

        add(lbGram);
        add(tfGram);

        add(btnHitung);
        add(btnSimpan);
        add(btnBack);

        add(lbHasilMakanan);
        add(hasilMakanan);

        add(lbKalori);
        add(hasilKalori);

        add(lbProtein);
        add(hasilProtein);

        add(lbKarbo);
        add(hasilKarbo);

        add(lbLemak);
        add(hasilLemak);

        // ================= ACTION =================

        btnCari.addActionListener(e -> {

            cariMakanan();
        });

        btnHitung.addActionListener(e -> {

            hitungNutrisi();
        });

        btnSimpan.addActionListener(e -> {

            simpanKonsumsi();
        });

        btnBack.addActionListener(e -> {

            new DashboardMember(member);

            dispose();
        });

        setVisible(true);
    }

    // ================= CARI MAKANAN =================

    public void cariMakanan() {

        String keyword =
                tfCari.getText().toLowerCase();

        if (keyword.isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "Input nama makanan!");

            return;
        }

        boolean ditemukan = false;

        for (int i = 0; i < listMakanan.size(); i++) {

            Makanan makanan =
                    listMakanan.get(i);

            if (makanan.getNama_makanan()
                    .toLowerCase()
                    .contains(keyword)) {

                cbMakanan.setSelectedIndex(i);

                ditemukan = true;

                break;
            }
        }

        if (!ditemukan) {

            JOptionPane.showMessageDialog(
                    null,
                    "Makanan tidak ditemukan!");
        }
    }

    // ================= HITUNG =================

    public void hitungNutrisi() {

        try {

            double[] hasil =
                    hitungData();

            hasilKalori.setText(
                    String.format("%.2f kcal", hasil[0]));

            hasilProtein.setText(
                    String.format("%.2f g", hasil[1]));

            hasilKarbo.setText(
                    String.format("%.2f g", hasil[2]));

            hasilLemak.setText(
                    String.format("%.2f g", hasil[3]));

            int index =
                    cbMakanan.getSelectedIndex();

            hasilMakanan.setText(
                    listMakanan.get(index)
                            .getNama_makanan());

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Input gram harus angka!");
        }
    }

    // ================= METHOD HITUNG =================

    public double[] hitungData() {

        int index =
                cbMakanan.getSelectedIndex();

        Makanan makanan =
                listMakanan.get(index);

        double gram =
                Double.parseDouble(
                        tfGram.getText());

        double totalKalori =
                (gram / 100)
                * makanan.getKalori();

        double totalProtein =
                (gram / 100)
                * makanan.getProtein();

        double totalKarbo =
                (gram / 100)
                * makanan.getKarbohidrat();

        double totalLemak =
                (gram / 100)
                * makanan.getLemak();

        return new double[]{
            totalKalori,
            totalProtein,
            totalKarbo,
            totalLemak
        };
    }

    // ================= SIMPAN =================

    public void simpanKonsumsi() {

        try {

            if (tfGram.getText().isEmpty()) {

                JOptionPane.showMessageDialog(
                        null,
                        "Input gram terlebih dahulu!");

                return;
            }

            int index =
                    cbMakanan.getSelectedIndex();

            Makanan makanan =
                    listMakanan.get(index);

            double gram =
                    Double.parseDouble(
                            tfGram.getText());

            double[] hasil =
                    hitungData();

            Konsumsi konsumsi =
                    new Konsumsi();

            konsumsi.setId_member(
                    member.getId_member());

            konsumsi.setId_makanan(
                    makanan.getId_makanan());

            konsumsi.setTanggal(
                    new Date(
                            System.currentTimeMillis()));

            konsumsi.setJumlah_porsi(
                    gram);

            konsumsi.setTotal_kalori(
                    hasil[0]);

            konsumsi.setTotal_protein(
                    hasil[1]);

            konsumsi.setTotal_karbo(
                    hasil[2]);

            konsumsi.setTotal_lemak(
                    hasil[3]);

            boolean sukses =
                    controller.insertKonsumsi(
                            konsumsi);

            if (sukses) {

                JOptionPane.showMessageDialog(
                        null,
                        "Konsumsi berhasil disimpan!");

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "Gagal menyimpan konsumsi!");
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Gram harus angka!");

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    e.getMessage());
        }
    }
}