/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import Controller.ControllerKonsumsi; 
import Model.DataMakanan.Makanan;
import Model.Konsumsi.Konsumsi;
import Model.Users.Member;
import View.Dashboard.DashboardMember;
import View.Progress.ViewProgress;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * @author Asus
 */

public class KonsumsiMakanan extends JFrame {

    List<Makanan> listMakanan;
    Member member;

    ControllerKonsumsi controller = new ControllerKonsumsi();

    public DateTimeFormatter fmtTampil =
            DateTimeFormatter.ofPattern("d MMMM yyyy", new Locale("id", "ID"));
    public DateTimeFormatter fmtDB =
            DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private Makanan makananTerpilih = null;

    public KonsumsiMakanan(List<Makanan> listMakanan, Member member) {
        this.listMakanan = listMakanan;
        this.member = member;

        setTitle("Konsumsi Makanan");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        buildUI();
        setVisible(true);
    }

    private void buildUI() {

        Font bold = new Font("Segoe UI", Font.BOLD, 13);
        Font plain = new Font("Segoe UI", Font.PLAIN, 13);
        Font small = new Font("Segoe UI", Font.ITALIC, 10);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 250, 255));

        JPanel card = new JPanel(new BorderLayout(0, 15));
        card.setPreferredSize(new Dimension(440, 580)); 
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
        ));

        JLabel lbTitle = new JLabel("KONSUMSI MAKANAN", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbTitle.setForeground(new Color(33, 150, 243));

        JLabel lbHalo = new JLabel("Halo, " + member.getNama() + "!");
        lbHalo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbHalo.setForeground(new Color(76, 175, 80));

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(Color.WHITE);
        lbTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        lbHalo.setAlignmentX(Component.CENTER_ALIGNMENT);
        top.add(lbTitle);
        top.add(Box.createVerticalStrut(4));
        top.add(lbHalo);

        card.add(top, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbTanggal = new JLabel("Tanggal");
        lbTanggal.setFont(bold);

        JTextField tfTanggal = new JTextField(LocalDate.now().format(fmtTampil));
        tfTanggal.setFont(plain);

        JLabel lbHintTanggal = new JLabel("Contoh format: 30 Mei 2026");
        lbHintTanggal.setFont(small);
        lbHintTanggal.setForeground(new Color(120, 120, 120));

        JLabel lbCari = new JLabel("Cari Makanan");
        lbCari.setFont(bold);

        JTextField tfCari = new JTextField();
        tfCari.setFont(plain);

        DefaultListModel<Makanan> model = new DefaultListModel<>();
        JList<Makanan> list = new JList<>(model);
        list.setFont(plain);
        
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Makanan) {
                    setText(((Makanan) value).getNama_makanan());
                }
                return this;
            }
        });

        JScrollPane scrollPopup = new JScrollPane(list);
        scrollPopup.setPreferredSize(new Dimension(280, 150));

        JPopupMenu menuMelayang = new JPopupMenu();
        menuMelayang.setBorder(BorderFactory.createEmptyBorder());
        menuMelayang.add(scrollPopup);
        menuMelayang.setFocusable(false); 

        JLabel lbSelected = new JLabel("Belum dipilih");
        lbSelected.setFont(small);
        lbSelected.setForeground(new Color(33, 150, 243));

        JLabel lbGram = new JLabel("Jumlah Gram");
        lbGram.setFont(bold);

        JTextField tfGram = new JTextField();
        tfGram.setFont(plain);

        JButton btnHitung = new JButton("Hitung");
        JButton btnSimpan = new JButton("Simpan");
        JButton btnBack = new JButton("Kembali");
        JButton btnProgress = new JButton("Lihat Progress");

        style(btnHitung, new Color(33,150,243));
        style(btnSimpan, new Color(76,175,80));
        style(btnBack, new Color(120,120,120));
        style(btnProgress, new Color(255,152,0));

        gc.gridx=0; gc.gridy=0; form.add(lbTanggal,gc);
        gc.gridx=1; form.add(tfTanggal,gc);

        gc.gridx=1; gc.gridy=1; form.add(lbHintTanggal,gc);

        gc.gridx=0; gc.gridy=2; form.add(lbCari,gc);
        gc.gridx=1; form.add(tfCari,gc);

        gc.gridx=1; gc.gridy=3; form.add(lbSelected,gc);

        gc.gridx=0; gc.gridy=4; form.add(lbGram,gc);
        gc.gridx=1; form.add(tfGram,gc);

        JPanel rowBtn = new JPanel(new GridLayout(1,2,10,0));
        rowBtn.setBackground(Color.WHITE);
        rowBtn.add(btnHitung);
        rowBtn.add(btnSimpan);

        gc.gridx=0; gc.gridy=5; gc.gridwidth=2;
        form.add(rowBtn,gc);

        JLabel hNama = new JLabel("-");
        JLabel hKal = new JLabel("0");
        JLabel hPro = new JLabel("0");
        JLabel hKar = new JLabel("0");
        JLabel hLem = new JLabel("0");

        JLabel[] h = {hNama,hKal,hPro,hKar,hLem};
        String[] n = {"Makanan","Kalori","Protein","Karbo","Lemak"};

        gc.gridwidth=1;
        for(int i=0;i<5;i++){
            gc.gridx=0; gc.gridy=6+i;
            JLabel l = new JLabel(n[i]);
            l.setFont(bold);
            form.add(l,gc);

            gc.gridx=1;
            h[i].setFont(plain);
            form.add(h[i],gc);
        }

        JPanel bottom = new JPanel(new GridLayout(1,2,10,0));
        bottom.setBackground(Color.WHITE);
        bottom.add(btnBack);
        bottom.add(btnProgress);

        gc.gridx=0; gc.gridy=12; gc.gridwidth=2;
        form.add(bottom,gc);

        card.add(new JScrollPane(form), BorderLayout.CENTER);
        wrapper.add(card);
        add(wrapper);

        tfCari.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN) {
                    return;
                }

                String keyword = tfCari.getText().toLowerCase().trim();
                model.clear();

                if (!keyword.isEmpty()) {
                    for (Makanan m : listMakanan) {
                        if (m.getNama_makanan().toLowerCase().contains(keyword)) {
                            model.addElement(m); 
                        }
                    }
                }

                if (model.isEmpty()) {
                    menuMelayang.setVisible(false);
                } else {
                    menuMelayang.show(tfCari, 0, tfCari.getHeight());
                    tfCari.requestFocus(); 
                }
            }
        });

        tfCari.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DOWN && menuMelayang.isShowing()) {
                    list.requestFocus();
                    list.setSelectedIndex(0);
                }
            }
        });

        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Makanan m = list.getSelectedValue();
                if (m != null) {
                    pilihMakanan(m, tfCari, lbSelected, menuMelayang);
                }
            }
        });

        list.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    Makanan m = list.getSelectedValue();
                    if (m != null) {
                        pilihMakanan(m, tfCari, lbSelected, menuMelayang);
                    }
                }
            }
        });

        btnHitung.addActionListener(e->{
            try{
                if(makananTerpilih == null){
                    JOptionPane.showMessageDialog(null,"Pilih makanan dulu dari daftar!");
                    return;
                }

                double gram = Double.parseDouble(tfGram.getText().trim());

                hNama.setText(makananTerpilih.getNama_makanan());
                hKal.setText(String.format("%.2f",(gram/100)*makananTerpilih.getKalori()));
                hPro.setText(String.format("%.2f",(gram/100)*makananTerpilih.getProtein()));
                hKar.setText(String.format("%.2f",(gram/100)*makananTerpilih.getKarbohidrat()));
                hLem.setText(String.format("%.2f",(gram/100)*makananTerpilih.getLemak()));

            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(null,"Jumlah gram harus berupa angka!");
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,"Terjadi kesalahan: " + ex.getMessage());
            }
        });

        btnSimpan.addActionListener(e->{
            try{
                if(makananTerpilih == null) {
                    JOptionPane.showMessageDialog(null,"Pilih makanan dulu!");
                    return;
                }

                String inputTanggal = tfTanggal.getText().trim();
                if (inputTanggal.contains("mei")) inputTanggal = inputTanggal.replace("mei", "Mei");
                if (inputTanggal.contains("juni")) inputTanggal = inputTanggal.replace("juni", "Juni");

                LocalDate tgl = LocalDate.parse(inputTanggal, fmtTampil);
                double gram = Double.parseDouble(tfGram.getText().trim());

                double kalori = (gram / 100) * makananTerpilih.getKalori();
                double protein = (gram / 100) * makananTerpilih.getProtein();
                double karbo = (gram / 100) * makananTerpilih.getKarbohidrat();
                double lemak = (gram / 100) * makananTerpilih.getLemak();

                Konsumsi k = new Konsumsi();
                k.setId_member(member.getId_member());
                k.setId_makanan(makananTerpilih.getId_makanan());
                k.setTanggal(Date.valueOf(tgl.format(fmtDB)));
                k.setJumlah_porsi(gram);
                
                k.setTotal_kalori(kalori);
                k.setTotal_protein(protein);
                k.setTotal_karbo(karbo);
                k.setTotal_lemak(lemak);

                controller.insertKonsumsi(k);

                JOptionPane.showMessageDialog(null,"Data Konsumsi Berhasil Tersimpan!");
                tfGram.setText("");
                tfCari.setText("");
                lbSelected.setText("Belum dipilih");
                makananTerpilih = null;

                hNama.setText("-"); hKal.setText("0"); hPro.setText("0"); hKar.setText("0"); hLem.setText("0");

            }catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(null,"Jumlah gram harus berupa angka!");
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null, "Format tanggal salah atau terjadi error database!\nIkuti pola contoh: 30 Mei 2026");
                ex.printStackTrace();
            }
        });

        btnBack.addActionListener(e->{
            new DashboardMember(member);
            dispose();
        });

        btnProgress.addActionListener(e->{
            new ViewProgress(member);
            dispose();
        });
    }

    private void pilihMakanan(Makanan m, JTextField tfCari, JLabel lbSelected, JPopupMenu menuMelayang) {
        makananTerpilih = m;
        tfCari.setText(m.getNama_makanan());
        lbSelected.setText("✔ " + m.getNama_makanan());
        menuMelayang.setVisible(false);
    }

    private void style(JButton b, Color c){
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI",Font.BOLD,13));
        b.setFocusPainted(false);
    }
}