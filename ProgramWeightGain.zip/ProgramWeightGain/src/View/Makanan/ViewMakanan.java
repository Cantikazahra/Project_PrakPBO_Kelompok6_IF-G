/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import Controller.ControllerMakanan;
import View.Dashboard.DashboardAdmin;
import Model.DataMakanan.DAOMakanan;
import Model.DataMakanan.InterfaceDAOMakanan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class ViewMakanan extends JFrame {

    InterfaceDAOMakanan daoMakanan;
    ControllerMakanan controller;

    DefaultTableModel model;
    JTable table;

    JButton btnTambah = new JButton("Tambah");
    JButton btnEdit   = new JButton("Edit");
    JButton btnHapus  = new JButton("Hapus");
    JButton btnBack   = new JButton("Back");

    public ViewMakanan() {

        daoMakanan = new DAOMakanan();
        controller = new ControllerMakanan();

        setTitle("Data Makanan");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 250, 255));

        JPanel header = new JPanel(new GridBagLayout());
        header.setBackground(new Color(33, 150, 243));
        header.setBorder(new EmptyBorder(16, 20, 16, 20));

        JLabel lbTitle = new JLabel("DATA MAKANAN");
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTitle.setForeground(Color.WHITE);
        header.add(lbTitle);
        add(header, BorderLayout.NORTH);

        String[] kolom = {
            "ID", "Nama Makanan", "Kalori", "Protein (g)", "Karbohidrat (g)", "Lemak (g)"
        };

        model = new DefaultTableModel(kolom, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };

        muatData();

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(21, 101, 192));
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 36));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setSelectionBackground(new Color(187, 222, 251));

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object v, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                if (!sel) {
                    setBackground(row % 2 == 0 ? Color.WHITE : new Color(232, 244, 253));
                }
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(200, 210, 220)));

        JPanel cardPanel = new JPanel(new BorderLayout());
        cardPanel.setBackground(Color.WHITE);
        cardPanel.setPreferredSize(new Dimension(1050, 560));
        cardPanel.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));

        JLabel cardTitle = new JLabel("DATA MAKANAN", SwingConstants.CENTER);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 32));
        cardTitle.setForeground(new Color(33, 150, 243));
        cardTitle.setBorder(new EmptyBorder(20, 0, 20, 0));

        cardPanel.add(cardTitle, BorderLayout.NORTH);
        cardPanel.add(scroll, BorderLayout.CENTER);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(240, 245, 250));
        wrapper.add(cardPanel);
        add(wrapper, BorderLayout.CENTER);

        styleBtn(btnTambah, new Color(76, 175, 80));
        styleBtn(btnEdit, new Color(33, 150, 243));
        styleBtn(btnHapus, new Color(244, 67, 54));
        styleBtn(btnBack, new Color(120, 120, 120));

        for (JButton b : new JButton[]{btnTambah, btnEdit, btnHapus, btnBack}) {
            b.setPreferredSize(new Dimension(140, 42));
        }

        JPanel south = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 14));
        south.setBackground(new Color(245, 250, 255));
        south.add(btnTambah);
        south.add(btnEdit);
        south.add(btnHapus);
        south.add(btnBack);
        add(south, BorderLayout.SOUTH);

        btnTambah.addActionListener(e -> {
            InputMakanan input = new InputMakanan(this);
            if (input.isDataTersimpan()) muatData();
        });

        btnEdit.addActionListener(e -> {
            int baris = table.getSelectedRow();
            if (baris < 0) {
                JOptionPane.showMessageDialog(null, "Pilih data terlebih dahulu!");
                return;
            }
            int id         = Integer.parseInt(model.getValueAt(baris, 0).toString());
            String nama    = model.getValueAt(baris, 1).toString();
            double kalori  = Double.parseDouble(model.getValueAt(baris, 2).toString());
            double protein = Double.parseDouble(model.getValueAt(baris, 3).toString());
            double karbo   = Double.parseDouble(model.getValueAt(baris, 4).toString());
            double lemak   = Double.parseDouble(model.getValueAt(baris, 5).toString());

            EditMakanan edit = new EditMakanan(this, id, nama, kalori, protein, karbo, lemak);
            if (edit.isDataTersimpan()) muatData();
        });

        btnHapus.addActionListener(e -> {
            int baris = table.getSelectedRow();
            if (baris < 0) {
                JOptionPane.showMessageDialog(null, "Pilih data terlebih dahulu!");
                return;
            }
            int id = Integer.parseInt(model.getValueAt(baris, 0).toString());
            int ok = JOptionPane.showConfirmDialog(
                    null, "Yakin ingin menghapus data?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if (ok == JOptionPane.YES_OPTION) {
                boolean sukses = controller.deleteMakanan(id);
                if (sukses) {
                    muatData();
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                }
            }
        });

        btnBack.addActionListener(e -> {
            new DashboardAdmin();
            dispose();
        });

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void muatData() {
        model.setRowCount(0);
        daoMakanan.getAll().forEach(m -> {
            model.addRow(new Object[]{
                m.getId_makanan(),
                m.getNama_makanan(),
                m.getKalori(),
                m.getProtein(),
                m.getKarbohidrat(),
                m.getLemak()
            });
        });
    }

    public JTable getTable() { 
        return table; 
    }
    public JButton getBtnTambah() {
        return btnTambah; 
    }
    public JButton getBtnEdit() { 
        return btnEdit; 
    }
    public JButton getBtnHapus() { 
        return btnHapus; 
    }
    public JButton getBtnBack() { 
        return btnBack; 
    }

    private void styleBtn(JButton b, Color c) {
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
    }
}