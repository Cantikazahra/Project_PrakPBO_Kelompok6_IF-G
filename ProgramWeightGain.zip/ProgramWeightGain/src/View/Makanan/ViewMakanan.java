/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import View.Dashboard.DashboardAdmin;
import Model.DataMakanan.DAOMakanan;
import Model.DataMakanan.InterfaceDAOMakanan;
import Model.DataMakanan.ModelTableMakanan;
import javax.swing.*;

/**
 *
 * @author Asus
 */

public class ViewMakanan extends JFrame {

    InterfaceDAOMakanan daoMakanan;

    JLabel title =
            new JLabel("DATA MAKANAN");

    JTable table =
            new JTable();

    JScrollPane scrollPane =
            new JScrollPane(table);

    JButton btnTambah =
            new JButton("Tambah");

    JButton btnEdit =
            new JButton("Edit");

    JButton btnHapus =
            new JButton("Hapus");

    JButton btnBack =
            new JButton("Back");

    public ViewMakanan() {

        daoMakanan = new DAOMakanan();

        setTitle("View Makanan");

        setSize(800, 500);

        setLayout(null);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= TITLE =================

        title.setBounds(330, 20, 200, 30);

        // ================= TABLE =================

        scrollPane.setBounds(
                30,
                70,
                720,
                250);

        // ================= BUTTON =================

        btnTambah.setBounds(
                70,
                370,
                120,
                40);

        btnEdit.setBounds(
                220,
                370,
                120,
                40);

        btnHapus.setBounds(
                370,
                370,
                120,
                40);

        btnBack.setBounds(
                520,
                370,
                120,
                40);

        // ================= ADD =================

        add(title);

        add(scrollPane);

        add(btnTambah);

        add(btnEdit);

        add(btnHapus);

        add(btnBack);

        // ================= LOAD TABLE =================

        loadTable();

        // ================= ACTION TAMBAH =================

        btnTambah.addActionListener(e -> {

            new InputMakanan();

            dispose();
        });

        // ================= ACTION EDIT =================

        btnEdit.addActionListener(e -> {

            int baris = table.getSelectedRow();

            if (baris == -1) {

                JOptionPane.showMessageDialog(
                        null,
                        "Pilih data terlebih dahulu!");

                return;
            }

            int id = Integer.parseInt(
                    table.getValueAt(baris, 0).toString());

            String nama = table.getValueAt(
                    baris, 1).toString();

            double kalori = Double.parseDouble(
                    table.getValueAt(baris, 2).toString());

            double protein = Double.parseDouble(
                    table.getValueAt(baris, 3).toString());

            double karbo = Double.parseDouble(
                    table.getValueAt(baris, 4).toString());

            double lemak = Double.parseDouble(
                    table.getValueAt(baris, 5).toString());

            new EditMakanan(
                    id,
                    nama,
                    kalori,
                    protein,
                    karbo,
                    lemak);

            dispose();
        });

        // ================= ACTION HAPUS =================

        btnHapus.addActionListener(e -> {

            int baris = table.getSelectedRow();

            if (baris == -1) {

                JOptionPane.showMessageDialog(
                        null,
                        "Pilih data terlebih dahulu!");

                return;
            }

            int id = Integer.parseInt(
                    table.getValueAt(baris, 0).toString());

            int konfirmasi = JOptionPane.showConfirmDialog(
                    null,
                    "Yakin ingin menghapus data?",
                    "Konfirmasi",
                    JOptionPane.YES_NO_OPTION);

            if (konfirmasi == JOptionPane.YES_OPTION) {

                daoMakanan.delete(id);

                loadTable();

                JOptionPane.showMessageDialog(
                        null,
                        "Data berhasil dihapus!");
            }
        });

        // ================= ACTION BACK =================

        btnBack.addActionListener(e -> {

            new DashboardAdmin();

            dispose();
        });

        setVisible(true);
    }

    // ================= LOAD TABLE =================

    public void loadTable() {

        table.setModel(
                new ModelTableMakanan(
                        daoMakanan.getAll()));
    }

    // ================= GETTER =================

    public JTable getTable() {

        return table;
    }

    public JButton getBtnTambah() {

        return btnTambah;
    }

    public JButton getBtnEdit() {

        return btnEdit;
    }

    public JButton getBtnHapus() {

        return btnHapus;
    }

    public JButton getBtnBack() {

        return btnBack;
    }
}