/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import Model.DataMakanan.DAOMakanan;
import Model.DataMakanan.InterfaceDAOMakanan;
import Model.DataMakanan.Makanan;
import javax.swing.*;


/**
 *
 * @author Asus
 */
public class EditMakanan extends JFrame {

    InterfaceDAOMakanan daoMakanan;

    JLabel title =
            new JLabel("EDIT MAKANAN");

    JLabel lbId =
            new JLabel("ID");

    JLabel lbNama =
            new JLabel("Nama Makanan");

    JLabel lbKalori =
            new JLabel("Kalori");

    JLabel lbProtein =
            new JLabel("Protein");

    JLabel lbKarbo =
            new JLabel("Karbohidrat");

    JLabel lbLemak =
            new JLabel("Lemak");

    JTextField tfId =
            new JTextField();

    JTextField tfNama =
            new JTextField();

    JTextField tfKalori =
            new JTextField();

    JTextField tfProtein =
            new JTextField();

    JTextField tfKarbo =
            new JTextField();

    JTextField tfLemak =
            new JTextField();

    JButton btnUpdate =
            new JButton("Update");

    JButton btnBack =
            new JButton("Back");

    public EditMakanan(
            int id,
            String nama,
            double kalori,
            double protein,
            double karbo,
            double lemak) {

        daoMakanan = new DAOMakanan();

        setTitle("Edit Makanan");

        setSize(400, 500);

        setLayout(null);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= TITLE =================

        title.setBounds(120, 20, 200, 30);

        // ================= LABEL =================

        lbId.setBounds(30, 70, 120, 25);

        lbNama.setBounds(30, 120, 120, 25);

        lbKalori.setBounds(30, 170, 120, 25);

        lbProtein.setBounds(30, 220, 120, 25);

        lbKarbo.setBounds(30, 270, 120, 25);

        lbLemak.setBounds(30, 320, 120, 25);

        // ================= TEXTFIELD =================

        tfId.setBounds(150, 70, 180, 25);

        // ID tampil tapi tidak bisa diedit
        tfId.setEditable(false);

        tfNama.setBounds(150, 120, 180, 25);

        tfKalori.setBounds(150, 170, 180, 25);

        tfProtein.setBounds(150, 220, 180, 25);

        tfKarbo.setBounds(150, 270, 180, 25);

        tfLemak.setBounds(150, 320, 180, 25);

        // ================= BUTTON =================

        btnUpdate.setBounds(50, 390, 120, 40);

        btnBack.setBounds(200, 390, 120, 40);

        // ================= ADD =================

        add(title);

        add(lbId);
        add(lbNama);
        add(lbKalori);
        add(lbProtein);
        add(lbKarbo);
        add(lbLemak);

        add(tfId);
        add(tfNama);
        add(tfKalori);
        add(tfProtein);
        add(tfKarbo);
        add(tfLemak);

        add(btnUpdate);
        add(btnBack);

        // ================= SET DATA =================

        setData(
                id,
                nama,
                kalori,
                protein,
                karbo,
                lemak);

        // ================= ACTION UPDATE =================

        btnUpdate.addActionListener(e -> {

            try {

                Makanan makanan = new Makanan();

                makanan.setId_makanan(getId());
                
                makanan.setNama_makanan(
                        getNamaMakanan());

                makanan.setKalori(
                        getKalori());

                makanan.setProtein(
                        getProtein());

                makanan.setKarbohidrat(
                        getKarbohidrat());

                makanan.setLemak(
                        getLemak());

                daoMakanan.update(makanan);

                JOptionPane.showMessageDialog(
                        null,
                        "Data berhasil diupdate!");

                new ViewMakanan();

                dispose();

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Gagal update data!");
            }
        });

        // ================= ACTION BACK =================

        btnBack.addActionListener(e -> {

            new ViewMakanan();

            dispose();
        });

        setVisible(true);
    }

    // ================= SET DATA =================

    public void setData(
            int id,
            String nama,
            double kalori,
            double protein,
            double karbo,
            double lemak) {

        tfId.setText(String.valueOf(id));

        tfNama.setText(nama);

        tfKalori.setText(String.valueOf(kalori));

        tfProtein.setText(String.valueOf(protein));

        tfKarbo.setText(String.valueOf(karbo));

        tfLemak.setText(String.valueOf(lemak));
    }

    // ================= GETTER =================

    public int getId() {

        return Integer.parseInt(
                tfId.getText());
    }

    public String getNamaMakanan() {

        return tfNama.getText();
    }

    public double getKalori() {

        return Double.parseDouble(
                tfKalori.getText());
    }

    public double getProtein() {

        return Double.parseDouble(
                tfProtein.getText());
    }

    public double getKarbohidrat() {

        return Double.parseDouble(
                tfKarbo.getText());
    }

    public double getLemak() {

        return Double.parseDouble(
                tfLemak.getText());
    }

    public JButton getBtnUpdate() {

        return btnUpdate;
    }

    public JButton getBtnBack() {

        return btnBack;
    }
}
