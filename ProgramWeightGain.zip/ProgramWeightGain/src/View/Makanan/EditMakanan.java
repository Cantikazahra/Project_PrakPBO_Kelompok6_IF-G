/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Makanan;

import Controller.ControllerMakanan;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class EditMakanan extends JDialog {

    private ControllerMakanan controller;
    private boolean dataTersimpan = false;

    JTextField tfNama = new JTextField();
    JTextField tfKalori = new JTextField();
    JTextField tfProtein = new JTextField();
    JTextField tfKarbo = new JTextField();
    JTextField tfLemak = new JTextField();

    JButton btnSimpan = new JButton("Simpan");
    JButton btnBatal = new JButton("Batal");

    public EditMakanan(
            JFrame parent,
            int id,
            String nama,
            double kalori,
            double protein,
            double karbo,
            double lemak
    ) {

        super(parent, "Edit Data Makanan", true);

        controller = new ControllerMakanan();

        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBackground(Color.WHITE);
        content.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel title = new JLabel("EDIT DATA MAKANAN", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(new Color(33, 150, 243));
        content.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        String[] labels = {"Nama Makanan", "Kalori", "Protein (g)", "Karbohidrat (g)", "Lemak (g)"};
        JTextField[] fields = {tfNama, tfKalori, tfProtein, tfKarbo, tfLemak};

        tfNama.setText(nama);
        tfKalori.setText(String.valueOf(kalori));
        tfProtein.setText(String.valueOf(protein));
        tfKarbo.setText(String.valueOf(karbo));
        tfLemak.setText(String.valueOf(lemak));

        for (int i = 0; i < labels.length; i++) {
            JLabel lb = new JLabel(labels[i]);
            lb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            fields[i].setPreferredSize(new Dimension(220, 35));
            fields[i].setFont(new Font("Segoe UI", Font.PLAIN, 13));

            gbc.gridx = 0; gbc.gridy = i;
            form.add(lb, gbc);
            gbc.gridx = 1;
            form.add(fields[i], gbc);
        }

        content.add(form, BorderLayout.CENTER);

        styleBtn(btnSimpan, new Color(33, 150, 243));
        styleBtn(btnBatal,  new Color(120, 120, 120));
        btnSimpan.setPreferredSize(new Dimension(130, 40));
        btnBatal.setPreferredSize(new Dimension(130, 40));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setBackground(Color.WHITE);
        btnPanel.add(btnSimpan);
        btnPanel.add(btnBatal);
        content.add(btnPanel, BorderLayout.SOUTH);

        add(content);

        btnSimpan.addActionListener(e -> {
            try {
                String namaBaru    = tfNama.getText().trim();
                double kaloriBaru  = Double.parseDouble(tfKalori.getText().trim());
                double proteinBaru = Double.parseDouble(tfProtein.getText().trim());
                double karboBaru   = Double.parseDouble(tfKarbo.getText().trim());
                double lemakBaru   = Double.parseDouble(tfLemak.getText().trim());

                if (namaBaru.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Nama makanan tidak boleh kosong!");
                    return;
                }

                boolean sukses = controller.updateMakanan(id, namaBaru, kaloriBaru, proteinBaru, karboBaru, lemakBaru);
                if (sukses) {
                    JOptionPane.showMessageDialog(this, "Data berhasil diupdate!");
                    dataTersimpan = true;
                    dispose();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Input angka tidak valid!");
            }
        });

        btnBatal.addActionListener(e -> dispose());

        pack();
        setLocationRelativeTo(parent);
        setVisible(true);
    }

    public boolean isDataTersimpan() {
        return dataTersimpan;
    }

    private void styleBtn(JButton b, Color c) {
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
    }
}