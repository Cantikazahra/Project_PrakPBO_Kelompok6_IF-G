/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Login;

import Controller.ControllerRegister;
import View.Member.InputDataMember;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class RegisterView extends JFrame {

    JLabel title = new JLabel("CREATE ACCOUNT");

    JLabel lbUsername = new JLabel("Username");
    JLabel lbPassword = new JLabel("Password");
    JLabel lbRole = new JLabel("Role");

    JTextField tfUsername = new JTextField();
    JPasswordField pfPassword = new JPasswordField();

    JComboBox<String> cbRole = new JComboBox<>(new String[]{"member", "admin"});

    JButton btnRegister = new JButton("REGISTER");
    JButton btnBack = new JButton("BACK");

    public RegisterView() {

        setTitle("Register");
        setSize(420, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        getContentPane().setBackground(new Color(250, 250, 250));

        // TITLE
        title.setBounds(120, 20, 300, 40);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(76, 175, 80));

        // LABEL
        lbUsername.setBounds(60, 80, 200, 20);
        lbPassword.setBounds(60, 150, 200, 20);
        lbRole.setBounds(60, 220, 200, 20);

        Font f = new Font("Segoe UI", Font.PLAIN, 13);
        lbUsername.setFont(f);
        lbPassword.setFont(f);
        lbRole.setFont(f);

        // INPUT
        tfUsername.setBounds(60, 105, 290, 35);
        pfPassword.setBounds(60, 175, 290, 35);
        cbRole.setBounds(60, 245, 290, 35);

        // BUTTON
        btnRegister.setBounds(60, 320, 140, 40);
        btnBack.setBounds(210, 320, 140, 40);

        style(btnRegister, new Color(76, 175, 80));
        style(btnBack, new Color(244, 67, 54));

        add(title);
        add(lbUsername);
        add(lbPassword);
        add(lbRole);
        add(tfUsername);
        add(pfPassword);
        add(cbRole);
        add(btnRegister);
        add(btnBack);

        btnRegister.addActionListener(e -> {

            ControllerRegister controller = new ControllerRegister();

            boolean sukses = controller.register(
                    getUsername(),
                    getPassword(),
                    getRole()
            );

            if (sukses) {

                JOptionPane.showMessageDialog(null, "Register berhasil");

                dispose();

                if (getRole().equals("member")) {
                    new InputDataMember(getUsername());
                } else {
                    new LoginView();
                }

            } else {
                JOptionPane.showMessageDialog(null, "Register gagal");
            }
        });

        btnBack.addActionListener(e -> {
            new LoginView();
            dispose();
        });

        setVisible(true);
    }

    private void style(JButton b, Color c) {
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setFocusPainted(false);
    }

    public String getUsername() {
        return tfUsername.getText();
    }

    public String getPassword() {
        return String.valueOf(pfPassword.getPassword());
    }

    public String getRole() {
        return cbRole.getSelectedItem().toString();
    }
}