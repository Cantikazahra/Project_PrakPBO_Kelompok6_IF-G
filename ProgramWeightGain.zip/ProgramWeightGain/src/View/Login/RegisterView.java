/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Login;

import Controller.ControllerRegister;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class RegisterView extends JFrame {

    JLabel title    = new JLabel("CREATE ACCOUNT", SwingConstants.CENTER);
    JLabel lbUsername = new JLabel("Username");
    JLabel lbPassword = new JLabel("Password");
    JLabel lbRole     = new JLabel("Role");

    JTextField    tfUsername = new JTextField();
    JPasswordField pfPassword = new JPasswordField();
    JComboBox<String> cbRole = new JComboBox<>(new String[]{"member", "admin"});

    public JButton btnRegister = new JButton("REGISTER");
    public JButton btnBack     = new JButton("BACK");

    public RegisterView() {

        setTitle("Register");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel background = new JPanel(new GridBagLayout());
        background.setBackground(new Color(245, 250, 255));
        background.add(buildFormPanel());

        add(background);

        // Controller yang handle semua aksi, termasuk btnBack
        new ControllerRegister(this);

        setVisible(true);
    }

    private JPanel buildFormPanel() {

        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setPreferredSize(new Dimension(430, 430));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(25, 25, 25, 25)
        ));

        // TITLE
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(new Color(33, 150, 243));
        panel.add(title, BorderLayout.NORTH);

        // FORM
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font font = new Font("Segoe UI", Font.PLAIN, 13);

        JLabel[] labels   = { lbUsername, lbPassword, lbRole };
        JComponent[] fields = { tfUsername, pfPassword, cbRole };

        for (int i = 0; i < labels.length; i++) {
            labels[i].setFont(font);
            fields[i].setFont(font);
            fields[i].setPreferredSize(new Dimension(260, 35));

            gbc.gridx = 0; gbc.gridy = i * 2;
            form.add(labels[i], gbc);
            gbc.gridy = i * 2 + 1;
            form.add(fields[i], gbc);
        }

        panel.add(form, BorderLayout.CENTER);

        // BUTTON
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        btnPanel.setBackground(Color.WHITE);

        styleButton(btnRegister, new Color(33, 150, 243));
        styleButton(btnBack,     new Color(120, 120, 120));
        btnRegister.setPreferredSize(new Dimension(140, 40));
        btnBack.setPreferredSize(new Dimension(140, 40));

        btnPanel.add(btnRegister);
        btnPanel.add(btnBack);
        panel.add(btnPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void styleButton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
    }

    public String getUsername() { return tfUsername.getText(); }
    public String getPassword() { return String.valueOf(pfPassword.getPassword()); }
    public String getRole()     { return cbRole.getSelectedItem().toString(); }
}