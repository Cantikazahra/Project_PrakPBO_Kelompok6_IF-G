/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Login;

import Controller.ControllerLogin;
import Controller.ControllerMember;
import Model.Users.Member;
import View.Dashboard.DashboardAdmin;
import View.Dashboard.DashboardMember;
import View.Member.InputDataMember;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class LoginView extends JFrame {

    JLabel title = new JLabel("WEIGHT GAIN APP");

    JLabel lbUsername = new JLabel("Username");
    JLabel lbPassword = new JLabel("Password");

    JTextField tfUsername = new JTextField();
    JPasswordField pfPassword = new JPasswordField();

    JButton btnLogin = new JButton("LOGIN");
    JButton btnRegister = new JButton("REGISTER");

    public LoginView() {

        setTitle("Login");
        setSize(420, 420);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        getContentPane().setBackground(new Color(245, 250, 255));

        // TITLE
        title.setBounds(110, 30, 300, 40);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(33, 150, 243));

        // LABEL
        lbUsername.setBounds(60, 100, 200, 20);
        lbPassword.setBounds(60, 170, 200, 20);

        lbUsername.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // INPUT
        tfUsername.setBounds(60, 125, 290, 35);
        pfPassword.setBounds(60, 195, 290, 35);

        // BUTTON
        btnLogin.setBounds(60, 260, 140, 40);
        btnRegister.setBounds(210, 260, 140, 40);

        styleButton(btnLogin, new Color(33, 150, 243));
        styleButton(btnRegister, new Color(76, 175, 80));

        add(title);
        add(lbUsername);
        add(lbPassword);
        add(tfUsername);
        add(pfPassword);
        add(btnLogin);
        add(btnRegister);

        // ================= LOGIN =================
        btnLogin.addActionListener(e -> {

            String username = getUsername();
            String password = getPassword();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Isi semua field!");
                return;
            }

            // ADMIN LOGIN
            if (username.equalsIgnoreCase("admin") && password.equals("admin123")) {
                new DashboardAdmin();
                dispose();
                return;
            }

            // USER LOGIN
            ControllerLogin controller = new ControllerLogin();
            String role = controller.login(username, password);

            if (role == null) {
                JOptionPane.showMessageDialog(null, "Login gagal, silahkan Register terlebih dahulu!");
                return;
            }

            if ("member".equalsIgnoreCase(role)) {

                ControllerMember cm = new ControllerMember();
                Member member = cm.getDataMember(username);

                // ✔ FLOW YANG BENAR
                if (member != null) {
                    new DashboardMember(member);
                } else {
                    JOptionPane.showMessageDialog(null,
                            "Data member belum lengkap, silakan isi data terlebih dahulu!");
                    new InputDataMember(username);
                }

                dispose();
                return;
            }

            // ADMIN ROLE
            new DashboardAdmin();
            dispose();
        });

        // ================= REGISTER =================
        btnRegister.addActionListener(e -> {
            new RegisterView();
            dispose();
        });

        setVisible(true);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
    }

    public String getUsername() {
        return tfUsername.getText();
    }

    public String getPassword() {
        return String.valueOf(pfPassword.getPassword());
    }
}