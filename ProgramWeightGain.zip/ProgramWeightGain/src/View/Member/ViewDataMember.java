/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Member;

import Controller.ControllerMember;
import Model.Users.Member;
import Model.Users.MemberDAO;
import Model.Connector;
import View.Dashboard.DashboardAdmin;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 *
 * @author Asus
 */
public class ViewDataMember extends JFrame {

    MemberDAO dao = new MemberDAO(Connector.getConnection());
    ControllerMember controller = new ControllerMember();
    DefaultTableModel model;
    JTable table;

    public ViewDataMember() {
        setTitle("Data Member");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel background = new JPanel(new GridBagLayout());
        background.setBackground(new Color(245, 250, 255));

        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setPreferredSize(new Dimension(950, 520));
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(20, 20, 20, 20)
        ));

        buildUI(contentPanel);

        background.add(contentPanel);
        add(background);
        setVisible(true);
    }

    private void buildUI(JPanel parent) {
        // ===== HEADER =====
        JLabel lbTitle = new JLabel("DATA MEMBER", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTitle.setForeground(new Color(33, 150, 243));
        parent.add(lbTitle, BorderLayout.NORTH);

        // ===== TABLE =====
        String[] kolom = {
                "ID", "Nama", "Umur", "Tinggi (cm)", "Berat Awal (kg)", "Target (kg)", "Username"
        };

        model = new DefaultTableModel(kolom, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        muatData();

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.setSelectionBackground(new Color(187, 222, 251));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(33, 150, 243));
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(0, 35));

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column
            ) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 247, 255));
                }
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return c;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        parent.add(scroll, BorderLayout.CENTER);

        // ===== BUTTON =====
        // Mengubah teks tombol menjadi "Hapus Member"
        JButton btnHapus = new JButton("Hapus Member");
        JButton btnBack = new JButton("Kembali");

        // Mengubah warna style menjadi MERAH untuk tombol hapus
        styleBtn(btnHapus, new Color(244, 67, 54)); 
        styleBtn(btnBack, new Color(120, 120, 120));

        btnHapus.setPreferredSize(new Dimension(160, 40));
        btnBack.setPreferredSize(new Dimension(140, 40));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnPanel.setBackground(Color.WHITE);
        btnPanel.add(btnHapus);
        btnPanel.add(btnBack);

        parent.add(btnPanel, BorderLayout.SOUTH);

        // ===== ACTION =====
        btnHapus.addActionListener(e -> {
            int row = table.getSelectedRow();

            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Pilih member terlebih dahulu!");
                return;
            }

            // Memanggil fungsi hapus data langsung
            prosesHapusMember(row);
        });

        btnBack.addActionListener(e -> {
            new DashboardAdmin();
            dispose();
        });
    }

    private void muatData() {
        model.setRowCount(0);
        List<Member> list = dao.getAllMember();
        for (Member m : list) {
            model.addRow(new Object[]{
                    m.getId_member(),
                    m.getNama(),
                    m.getUmur(),
                    m.getTinggi_badan(),
                    m.getBerat_awal(),
                    m.getTarget_berat(),
                    m.getUsername()
            });
        }
    }

    // ===== PROSES HAPUS DATA MEMBER =====
    private void prosesHapusMember(int row) {
        // Mengambil ID dan Nama Member dari baris tabel yang dipilih
        int id = (int) model.getValueAt(row, 0);
        String nama = (String) model.getValueAt(row, 1);

        // Menampilkan dialog konfirmasi YES / NO agar aman
        int konfirmasi = JOptionPane.showConfirmDialog(
                this,
                "Apakah Anda yakin ingin menghapus member '" + nama + "'?",
                "Konfirmasi Hapus Data",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (konfirmasi == JOptionPane.YES_OPTION) {
            try {
                // Memanggil fungsi hapus dari controller
                // Catatan: Pastikan di kelas ControllerMember kamu sudah tersedia method deleteMember(int id)
                boolean sukses = controller.deleteMember(id);

                if (sukses) {
                    JOptionPane.showMessageDialog(this, "Data member berhasil dihapus!");
                    muatData(); // Refresh isi tabel data member
                } else {
                    JOptionPane.showMessageDialog(this, "Gagal menghapus data member.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Terjadi Kesalahan: " + ex.getMessage());
            }
        }
    }

    private void styleBtn(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
    }
}
