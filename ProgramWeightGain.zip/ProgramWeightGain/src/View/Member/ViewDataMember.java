/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Member;

import Model.Users.Member;
import Model.Users.MemberDAO;
import Model.Connector;
import View.Dashboard.DashboardAdmin;
import javax.swing.*;
import java.util.List;

/**
 *
 * @author Asus
 */

public class ViewDataMember extends JFrame {

    JLabel title = new JLabel("DATA MEMBER");

    JTable table;
    JScrollPane scrollPane;

    JButton btnBack = new JButton("Back");

    MemberDAO dao = new MemberDAO(Connector.getConnection());

    public ViewDataMember() {

        setTitle("Data Member");
        setSize(700, 400);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= TITLE =================
        title.setBounds(280, 20, 200, 30);

        // ================= DATA =================
        List<Member> list = dao.getAllMember();

        String[] kolom = {"ID", "Nama", "Umur", "Tinggi", "Berat", "Target", "Username", "Role"};
        String[][] data = new String[list.size()][8];

        for (int i = 0; i < list.size(); i++) {

            Member m = list.get(i);

            data[i][0] = String.valueOf(m.getId_member());
            data[i][1] = m.getNama();
            data[i][2] = String.valueOf(m.getUmur());
            data[i][3] = String.valueOf(m.getTinggi_badan());
            data[i][4] = String.valueOf(m.getBerat_awal());
            data[i][5] = String.valueOf(m.getTarget_berat());
            data[i][6] = String.valueOf(m.getUsername());
            data[i][7] = m.getRole();
        }

        table = new JTable(data, kolom);
        scrollPane = new JScrollPane(table);

        scrollPane.setBounds(30, 70, 620, 220);
        btnBack.setBounds(280, 320, 120, 40);

        add(title);
        add(scrollPane);
        add(btnBack);

        // ================= BACK =================
        btnBack.addActionListener(e -> {
            new DashboardAdmin();
            dispose();
        });

        setVisible(true);
    }
}