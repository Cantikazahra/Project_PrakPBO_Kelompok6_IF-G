/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Member;

import Controller.ControllerLogin;
import Controller.ControllerMember;
import Model.Users.Member;
import Model.Program.ProgramWeightGain;
import Model.Program.DAOProgram;
import View.Dashboard.DashboardMember;
import View.Login.LoginView;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class InputDataMember extends JFrame {

    private String username;

    private JLabel title =
            new JLabel("DATA MEMBER", SwingConstants.CENTER);

    private JTextField tfNama =
            new JTextField(15);

    private JTextField tfUmur =
            new JTextField(15);

    private JTextField tfTinggi =
            new JTextField(15);

    private JTextField tfBeratAwal =
            new JTextField(15);

    private JTextField tfTarget =
            new JTextField(15);

    private JTextField tfDurasi =
            new JTextField(15);
    
    private JButton btnSimpan =
            new JButton("Simpan");

    private JButton btnBack =
            new JButton("Back");

    public InputDataMember(String username) {

        this.username = username;

        init();
    }

    public InputDataMember() {

        init();
    }

    private void init() {

        setTitle("Input Data Member");

        setExtendedState(JFrame.MAXIMIZED_BOTH);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel wrapper =
                new JPanel(new GridBagLayout());

        wrapper.setBackground(
                new Color(245, 250, 255)
        );

        JPanel panel =
                new JPanel(new BorderLayout(15, 15));

        panel.setPreferredSize(
                new Dimension(540, 450)
        );

        panel.setBackground(Color.WHITE);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(220,220,220)
                        ),
                        new EmptyBorder(
                                25,
                                25,
                                25,
                                25
                        )
                )
        );

        // ================= TITLE =================

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        22
                )
        );

        title.setForeground(
                new Color(33,150,243)
        );

        panel.add(title, BorderLayout.NORTH);

        // ================= FORM =================

        JPanel formPanel =
                new JPanel(new GridBagLayout());

        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(10,10,10,10);

        gbc.fill =
                GridBagConstraints.HORIZONTAL;

        Font font =
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        14
                );

        String[] labels = {
                "Nama",
                "Umur",
                "Tinggi Badan (cm)",
                "Berat Awal (kg)",
                "Target Berat (kg)",
                "Durasi Program (bulan)"
        };

        JTextField[] fields = {
                tfNama,
                tfUmur,
                tfTinggi,
                tfBeratAwal,
                tfTarget,
                tfDurasi
        };

        for (int i = 0; i < labels.length; i++) {

            JLabel lb =
                    new JLabel(labels[i]);

            lb.setFont(font);

            fields[i].setFont(font);

            fields[i].setPreferredSize(
                    new Dimension(220,35)
            );

            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.weightx = 0;

            formPanel.add(lb, gbc);

            gbc.gridx = 1;
            gbc.weightx = 1;

            formPanel.add(fields[i], gbc);
        }

        panel.add(formPanel, BorderLayout.CENTER);

        // ================= BUTTON =================

        JPanel btnPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                20,
                                10
                        )
                );

        btnPanel.setBackground(Color.WHITE);

        styleBtn(
                btnSimpan,
                new Color(33,150,243)
        );

        styleBtn(
                btnBack,
                new Color(120,120,120)
        );

        btnSimpan.setPreferredSize(
                new Dimension(140,40)
        );

        btnBack.setPreferredSize(
                new Dimension(140,40)
        );

        btnPanel.add(btnSimpan);
        btnPanel.add(btnBack);

        panel.add(btnPanel, BorderLayout.SOUTH);

        wrapper.add(panel);

        add(wrapper);

        // ================= SIMPAN =================

        btnSimpan.addActionListener(e -> {

            try {

                String nama =
                        tfNama.getText().trim();

                int umur =
                        Integer.parseInt(
                                tfUmur.getText().trim()
                        );

                double tinggi =
                        Double.parseDouble(
                                tfTinggi.getText().trim()
                        );

                double beratAwal =
                        Double.parseDouble(
                                tfBeratAwal.getText().trim()
                        );

                double target =
                        Double.parseDouble(
                                tfTarget.getText().trim()
                        );

                int durasi =
                        Integer.parseInt(
                                tfDurasi.getText().trim()
                        );

                if (nama.isEmpty()) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Nama tidak boleh kosong!"
                    );

                    return;
                }

                ControllerMember controller =
                        new ControllerMember();

                boolean sukses =
                        controller.insertMember(
                                username,
                                nama,
                                umur,
                                tinggi,
                                beratAwal,
                                target
                        );

                if (sukses) {

                    Member member =
                            controller.getDataMember(
                                    username
                            );

                    if (member != null) {

                        double naikKg =
                                target - beratAwal;

                        if (naikKg < 0) {
                            naikKg = 0;
                        }

                        double surplusPerHari =
                                (naikKg * 7700)
                                / (durasi * 30.0);

                        double targetKalori =
                                2500 + surplusPerHari;

                        ProgramWeightGain program =
                                new ProgramWeightGain();

                        program.setId_member(
                                member.getId_member()
                        );

                        program.setTargetKalori(
                                targetKalori
                        );

                        program.setProtein(
                                targetKalori * 0.25 / 4
                        );

                        program.setKarbo(
                                targetKalori * 0.50 / 4
                        );

                        program.setLemak(
                                targetKalori * 0.25 / 9
                        );

                        program.setDurasiBulan(
                                durasi
                        );

                        DAOProgram daoProgram =
                                new DAOProgram();

                        daoProgram.insert(program);

                        JOptionPane.showMessageDialog(
                                this,
                                "Data member dan program berhasil disimpan!"
                        );

                        new DashboardMember(member);

                        dispose();
                    }
                }

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                        this,
                        "Semua input angka harus valid!"
                );
            }
        });

        // ================= BACK =================

        btnBack.addActionListener(e -> {

            LoginView lv =
                    new LoginView();

            new ControllerLogin(lv);

            dispose();
        });

        setVisible(true);
    }

    private void styleBtn(
            JButton btn,
            Color color
    ) {

        btn.setBackground(color);

        btn.setForeground(Color.WHITE);

        btn.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13
                )
        );

        btn.setFocusPainted(false);

        btn.setBorderPainted(false);
    }
}