/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Member;

import Controller.ControllerMember;
import Model.Users.Member;
import View.Dashboard.DashboardMember;
import View.Login.RegisterView;
import javax.swing.*;

/**
 *
 * @author Asus
 */

public class InputDataMember extends JFrame {

    private String username;

    JLabel title = new JLabel("DATA MEMBER");

    JLabel lbNama = new JLabel("Nama");
    JLabel lbUmur = new JLabel("Umur");
    JLabel lbTinggi = new JLabel("Tinggi Badan");
    JLabel lbBeratAwal = new JLabel("Berat Awal");
    JLabel lbTarget = new JLabel("Target Berat");

    JTextField tfNama = new JTextField();
    JTextField tfUmur = new JTextField();
    JTextField tfTinggi = new JTextField();
    JTextField tfBeratAwal = new JTextField();
    JTextField tfTarget = new JTextField();

    JButton btnSimpan = new JButton("Simpan");
    JButton btnBack = new JButton("Back");

    public InputDataMember(String username) {
        this.username = username;
        init();
    }

    public InputDataMember() {
        init();
    }

    private void init() {

        setTitle("Input Member - " + (username == null ? "" : username));
        setSize(400, 500);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        title.setBounds(130, 20, 200, 30);

        lbNama.setBounds(30, 80, 120, 25);
        lbUmur.setBounds(30, 130, 120, 25);
        lbTinggi.setBounds(30, 180, 120, 25);
        lbBeratAwal.setBounds(30, 230, 120, 25);
        lbTarget.setBounds(30, 280, 120, 25);

        tfNama.setBounds(150, 80, 180, 25);
        tfUmur.setBounds(150, 130, 180, 25);
        tfTinggi.setBounds(150, 180, 180, 25);
        tfBeratAwal.setBounds(150, 230, 180, 25);
        tfTarget.setBounds(150, 280, 180, 25);

        btnSimpan.setBounds(50, 360, 120, 40);
        btnBack.setBounds(200, 360, 120, 40);

        add(title);
        add(lbNama);
        add(lbUmur);
        add(lbTinggi);
        add(lbBeratAwal);
        add(lbTarget);

        add(tfNama);
        add(tfUmur);
        add(tfTinggi);
        add(tfBeratAwal);
        add(tfTarget);

        add(btnSimpan);
        add(btnBack);

        // ================= SIMPAN =================
        btnSimpan.addActionListener(e -> {

            try {

                // VALIDASI USERNAME
                if (username == null || username.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Username tidak valid!");
                    return;
                }

                // VALIDASI INPUT KOSONG
                if (tfNama.getText().isEmpty() ||
                        tfUmur.getText().isEmpty() ||
                        tfTinggi.getText().isEmpty() ||
                        tfBeratAwal.getText().isEmpty() ||
                        tfTarget.getText().isEmpty()) {

                    JOptionPane.showMessageDialog(null, "Semua data harus diisi!");
                    return;
                }

                // PARSING DATA
                String nama = tfNama.getText();
                int umur = Integer.parseInt(tfUmur.getText());
                double tinggi = Double.parseDouble(tfTinggi.getText());
                double beratAwal = Double.parseDouble(tfBeratAwal.getText());
                double target = Double.parseDouble(tfTarget.getText());

                // INSERT KE DATABASE
                ControllerMember controller = new ControllerMember();

                boolean sukses = controller.insertMember(username, nama, umur, tinggi, beratAwal, target);

                if (sukses) {

                    JOptionPane.showMessageDialog(null, "Berhasil disimpan");

                    dispose();

                    // AMBIL DATA MEMBER DARI DATABASE
                    Member member = controller.getDataMember(username);

                    if (member != null) {
                        new DashboardMember(member);
                    } else {
                        JOptionPane.showMessageDialog(null, "Gagal mengambil data member!");
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Gagal simpan data");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Input angka tidak valid!");
            }
        });

        // ================= BACK =================
        btnBack.addActionListener(e -> {
            new RegisterView();
            dispose();
        });

        setVisible(true);
    }
}
