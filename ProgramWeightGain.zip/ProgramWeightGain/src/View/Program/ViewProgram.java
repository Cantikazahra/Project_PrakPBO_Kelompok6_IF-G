/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Program;

import Controller.ControllerProgram;
import Model.Program.DAOProgram;
import Model.Users.Member;

import javax.swing.*;
import java.awt.*;
/**
 *
 * @author Asus
 */

public class ViewProgram extends JFrame {

    Member member;

    public JButton btnLanjut = new JButton("Mulai Catat Progress");
    public JButton btnBack   = new JButton("Kembali");

    public ViewProgram(Member member, double kalori, double protein, double karbo, double lemak) {
        this.member = member;
        buildUI(kalori, protein, karbo, lemak);
    }

    public ViewProgram(Member member) {
        this.member = member;

        DAOProgram daoProgram = new DAOProgram();
        int durasi = daoProgram.getDurasiProgram(member.getId_member());
        if (durasi <= 0) durasi = 6;

        double selisihBB     = member.getTarget_berat() - member.getBerat_awal();
        double surplusPerHari = (selisihBB * 7700) / (durasi * 30.0);
        double bmr           = member.getBerat_awal() * 25 * 1.4;
        double kalori        = Math.round(bmr + surplusPerHari);
        double protein       = Math.round((kalori * 0.30) / 4);
        double karbo         = Math.round((kalori * 0.50) / 4);
        double lemak         = Math.round((kalori * 0.20) / 9);

        buildUI(kalori, protein, karbo, lemak);
    }

    private void buildUI(double kalori, double protein, double karbo, double lemak) {

        DAOProgram daoProgram = new DAOProgram();
        int durasi = daoProgram.getDurasiProgram(member.getId_member());
        if (durasi <= 0) durasi = 6;

        setTitle("Program Weight Gain");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ===== WRAPPER (background abu) =====
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 250, 255));

        // ===== CARD =====
        JPanel card = new JPanel(new BorderLayout(0, 15));
        card.setPreferredSize(new Dimension(480, 460));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
        ));

        // ===== TITLE =====
        JLabel lbTitle = new JLabel("PROGRAM WEIGHT GAIN", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbTitle.setForeground(new Color(76, 175, 80));
        card.add(lbTitle, BorderLayout.NORTH);

        // ===== CENTER =====
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(Color.WHITE);

        JLabel lbHalo = new JLabel("Halo, " + member.getNama() + "!");
        lbHalo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbHalo.setForeground(new Color(76, 175, 80));
        lbHalo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lbInfo = new JLabel("Target nutrisi harian kamu:");
        lbInfo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbInfo.setAlignmentX(Component.LEFT_ALIGNMENT);

        center.add(lbHalo);
        center.add(Box.createVerticalStrut(12));
        center.add(lbInfo);
        center.add(Box.createVerticalStrut(10));

        // ===== NUTRISI PANEL =====
        JPanel panelNutrisi = new JPanel(new GridBagLayout());
        panelNutrisi.setBackground(new Color(232, 245, 233));
        panelNutrisi.setAlignmentX(Component.LEFT_ALIGNMENT);
        panelNutrisi.setMaximumSize(new Dimension(Integer.MAX_VALUE, 180));
        panelNutrisi.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(165, 214, 167), 1, true),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));

        String[][] rows = {
            {"Kalori",      String.format("%.0f kcal/hari", kalori)},
            {"Protein",     String.format("%.0f g/hari",    protein)},
            {"Karbohidrat", String.format("%.0f g/hari",    karbo)},
            {"Lemak",       String.format("%.0f g/hari",    lemak)}
        };

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets  = new Insets(6, 8, 6, 20);
        gc.anchor  = GridBagConstraints.WEST;

        for (int i = 0; i < rows.length; i++) {
            gc.gridx = 0; gc.gridy = i;
            JLabel key = new JLabel(rows[i][0]);
            key.setFont(new Font("Segoe UI", Font.BOLD, 13));
            panelNutrisi.add(key, gc);

            gc.gridx = 1;
            JLabel val = new JLabel(rows[i][1]);
            val.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            panelNutrisi.add(val, gc);
        }

        center.add(panelNutrisi);
        center.add(Box.createVerticalStrut(12));

        JLabel lbKet = new JLabel(String.format(
                "Target berat %.1f kg dalam %d bulan",
                member.getTarget_berat(), durasi
        ));
        lbKet.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbKet.setAlignmentX(Component.LEFT_ALIGNMENT);
        center.add(lbKet);

        card.add(center, BorderLayout.CENTER);

        // ===== BUTTON =====
        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 12, 0));
        btnPanel.setBackground(Color.WHITE);

        styleBtn(btnLanjut, new Color(33, 150, 243));
        styleBtn(btnBack,   new Color(120, 120, 120));

        btnPanel.add(btnLanjut);
        btnPanel.add(btnBack);

        card.add(btnPanel, BorderLayout.SOUTH);

        wrapper.add(card);
        add(wrapper);

        new ControllerProgram(this, member);

        setVisible(true);
    }

    private void styleBtn(JButton b, Color c) {
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(180, 40));
    }
}
