/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package View.Program;

import javax.swing.*;
import java.awt.*;
import View.Dashboard.DashboardMember;
import Model.Users.Member;
/**
 *
 * @author Asus
 */

public class ViewProgram extends JFrame {

    // DATA MEMBER LOGIN
    Member member;

    JLabel title =
            new JLabel("PROGRAM WEIGHT GAIN");

    JLabel lbTargetKalori =
            new JLabel("Target Kalori Harian");

    JLabel lbProtein =
            new JLabel("Target Protein");

    JLabel lbKarbo =
            new JLabel("Target Karbohidrat");

    JLabel lbLemak =
            new JLabel("Target Lemak");

    JTextField tfKalori =
            new JTextField();

    JTextField tfProtein =
            new JTextField();

    JTextField tfKarbo =
            new JTextField();

    JTextField tfLemak =
            new JTextField();

    JButton btnHitung =
            new JButton("Hitung Program");

    JButton btnSimpan =
            new JButton("Simpan");

    JButton btnBack =
            new JButton("Back");

    // ================= CONSTRUCTOR =================

    public ViewProgram(Member member) {

        this.member = member;

        setTitle("Program Weight Gain");

        setSize(500, 450);

        setLayout(null);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        getContentPane().setBackground(new Color(245, 250, 255));

        // ================= TITLE =================

        title.setBounds(100, 20, 300, 30);

        title.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        22
                )
        );

        // ================= LABEL =================

        lbTargetKalori.setBounds(40, 100, 180, 25);
        lbProtein.setBounds(40, 150, 180, 25);
        lbKarbo.setBounds(40, 200, 180, 25);
        lbLemak.setBounds(40, 250, 180, 25);

        // ================= TEXTFIELD =================

        tfKalori.setBounds(250, 100, 150, 30);
        tfProtein.setBounds(250, 150, 150, 30);
        tfKarbo.setBounds(250, 200, 150, 30);
        tfLemak.setBounds(250, 250, 150, 30);

        // ================= BUTTON =================

        btnHitung.setBounds(40, 330, 150, 40);

        btnSimpan.setBounds(200, 330, 100, 40);

        btnBack.setBounds(310, 330, 100, 40);

        // ================= ADD COMPONENT =================

        add(title);

        add(lbTargetKalori);
        add(lbProtein);
        add(lbKarbo);
        add(lbLemak);

        add(tfKalori);
        add(tfProtein);
        add(tfKarbo);
        add(tfLemak);

        add(btnHitung);
        add(btnSimpan);
        add(btnBack);

        setVisible(true);
    }
    // ================= GETTER =================

    public JTextField getTfKalori() {
        return tfKalori;
    }

    public JTextField getTfProtein() {
        return tfProtein;
    }

    public JTextField getTfKarbo() {
        return tfKarbo;
    }

    public JTextField getTfLemak() {
        return tfLemak;
    }

    public JButton getBtnHitung() {
        return btnHitung;
    }

    public JButton getBtnSimpan() {
        return btnSimpan;
    }

    public JButton getBtnBack() {
        return btnBack;
    }
}