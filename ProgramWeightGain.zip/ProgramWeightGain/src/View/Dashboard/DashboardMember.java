/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Dashboard;

import javax.swing.*;
import java.awt.*;

import Controller.ControllerLogin;
import Controller.ControllerProgress;

import View.Makanan.KonsumsiMakanan;
import View.Program.ViewProgram;
import View.Progress.ViewProgress;
import View.Login.LoginView;

import Model.Program.DAOProgram;
import Model.DataMakanan.DAOMakanan;
import Model.Users.Member;

import java.util.List;

/**
 *
 * @author Asus
 */

public class DashboardMember extends JFrame {

    private Member member;

    JLabel lbTitle    = new JLabel("DASHBOARD MEMBER", SwingConstants.CENTER);
    JLabel lbHalo     = new JLabel("Halo!");
    JLabel lbUmur     = new JLabel("Umur : ");
    JLabel lbTinggi   = new JLabel("Tinggi : ");
    JLabel lbBerat    = new JLabel("Berat Awal : ");
    JLabel lbTarget   = new JLabel("Target Berat : ");
    JLabel lbBeratSkrg = new JLabel("Berat Sekarang : ");
    JLabel lbDurasi = new JLabel("Durasi Program : ");
    
    JButton btnMakanan  = new JButton("Konsumsi Makanan");
    JButton btnProgram  = new JButton("Program");
    JButton btnProgress = new JButton("Progress");
    JButton btnLogout   = new JButton("Logout");

    public DashboardMember(Member member) {
        this.member = member;
        initComponent();
        isiDataMember();
        setVisible(true);
    }

    private void initComponent() {

        setTitle("Dashboard Member");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 250, 255));

        JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
        mainPanel.setPreferredSize(new Dimension(520, 420));
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(25, 25, 25, 25)
        ));

        // ===== TITLE =====
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTitle.setForeground(new Color(33, 150, 243));
        mainPanel.add(lbTitle, BorderLayout.NORTH);

        // ===== DATA PANEL =====
        JPanel centerPanel = new JPanel(new GridLayout(7, 1, 0, 10));
        centerPanel.setBackground(Color.WHITE);

        Font dataFont = new Font("Segoe UI", Font.PLAIN, 14);

        lbHalo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lbHalo.setForeground(new Color(76, 175, 80));

        for (JLabel lb : new JLabel[]{ lbUmur, lbTinggi, lbBerat, lbTarget, lbDurasi, lbBeratSkrg }) {
            lb.setFont(dataFont);
        }

        centerPanel.add(lbHalo);
        centerPanel.add(lbUmur);
        centerPanel.add(lbTinggi);
        centerPanel.add(lbBerat);
        centerPanel.add(lbTarget);
        centerPanel.add(lbDurasi);
        centerPanel.add(lbBeratSkrg);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // ===== BUTTON PANEL =====
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 12, 12));
        buttonPanel.setBackground(Color.WHITE);

        styleBtn(btnMakanan,  new Color(33, 150, 243));
        styleBtn(btnProgram,  new Color(76, 175, 80));
        styleBtn(btnProgress, new Color(255, 152, 0));
        styleBtn(btnLogout,   new Color(244, 67, 54));

        buttonPanel.add(btnMakanan);
        buttonPanel.add(btnProgram);
        buttonPanel.add(btnProgress);
        buttonPanel.add(btnLogout);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        wrapper.add(mainPanel);
        add(wrapper);

        // ===== ACTION =====

        btnMakanan.addActionListener(e -> {
            try {
                new KonsumsiMakanan(new DAOMakanan().getAll(), member);
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Gagal membuka data makanan!");
            }
        });
        
        btnProgram.addActionListener(e -> {
            new ViewProgram(member);
            dispose();
        });

        btnProgress.addActionListener(e -> {
            new ViewProgress(member);
            dispose();
        });

        btnLogout.addActionListener(e -> {
            LoginView lv = new LoginView();
            new ControllerLogin(lv);
            dispose();
        });
    }

    private void isiDataMember() {

        lbHalo.setText("Halo, " + member.getNama() + "!");
        lbUmur.setText("Umur : " + member.getUmur() + " tahun");
        lbTinggi.setText("Tinggi : " + member.getTinggi_badan() + " cm");
        lbBerat.setText("Berat Awal : " + member.getBerat_awal() + " kg");
        lbTarget.setText("Target Berat : " + member.getTarget_berat() + " kg");
        
        try {

            DAOProgram daoProgram =
                    new DAOProgram();

            int durasi =
                    daoProgram.getDurasiProgram(
                            member.getId_member()
                    );

            lbDurasi.setText(
                    "Durasi Program : "
                    + durasi
                    + " bulan"
            );

        } catch (Exception e) {

            lbDurasi.setText(
                    "Durasi Program : -"
            );
        }
        try {
            ControllerProgress cp = new ControllerProgress();
            double beratSkrg = cp.getBeratTerakhir(member.getId_member());

            if (beratSkrg > 0) {
                double sisa = member.getTarget_berat() - beratSkrg;
                String sisaTeks = sisa > 0
                        ? String.format("(%.1f kg lagi!)", sisa)
                        : "(Yess Target tercapai!)";
                lbBeratSkrg.setText("Berat Sekarang : " + beratSkrg + " kg " + sisaTeks);
            } else {
                lbBeratSkrg.setText("Berat Sekarang : Belum dicatat");
            }
        } catch (Exception e) {
            lbBeratSkrg.setText("Berat Sekarang : -");
        }
    }

    private void styleBtn(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setPreferredSize(new Dimension(180, 40));
    }
}