/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Dashboard;

import javax.swing.*;

import View.Makanan.KonsumsiMakanan;
import View.Program.ViewProgram;
import View.Progress.ViewProgress;
import View.Login.LoginView;
import Controller.ControllerProgram;
import Model.DataMakanan.Makanan;
import Model.DataMakanan.DAOMakanan;
import Model.Users.Member;

import java.util.List;

/**
 *
 * @author Asus
 */
public class DashboardMember extends JFrame {

    JLabel title =
            new JLabel("DASHBOARD MEMBER");

    JLabel nama =
            new JLabel("Nama : ");

    JLabel umur =
            new JLabel("Umur : ");

    JLabel tinggi =
            new JLabel("Tinggi : ");

    JLabel berat =
            new JLabel("Berat Awal : ");

    JLabel target =
            new JLabel("Target : ");

    JButton btnMakanan =
            new JButton("Konsumsi Makanan");

    JButton btnProgram =
            new JButton("Program");

    JButton btnProgress =
            new JButton("Progress");

    JButton btnLogout =
            new JButton("Logout");

    // ================= DATA MEMBER =================

    Member member;

    // ================= DEFAULT CONSTRUCTOR =================

    public DashboardMember() {
        init();
    }

    // ================= CONSTRUCTOR MEMBER =================

    public DashboardMember(Member member) {

        this.member = member;

        init();

        // TAMPILKAN DATA MEMBER
        if (member != null) {

            setDataMember(
                    member.getNama(),
                    member.getUmur(),
                    member.getTinggi_badan(),
                    member.getBerat_awal(),
                    member.getTarget_berat()
            );
        }
    }

    // ================= INIT UI =================

    private void init() {

        setTitle("Dashboard Member");

        setSize(500, 400);

        setLayout(null);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= SET BOUNDS =================

        title.setBounds(
                140,
                20,
                250,
                30
        );

        nama.setBounds(
                50,
                80,
                300,
                30
        );

        umur.setBounds(
                50,
                110,
                300,
                30
        );

        tinggi.setBounds(
                50,
                140,
                300,
                30
        );

        berat.setBounds(
                50,
                170,
                300,
                30
        );

        target.setBounds(
                50,
                200,
                300,
                30
        );

        btnMakanan.setBounds(
                50,
                260,
                150,
                40
        );

        btnProgram.setBounds(
                250,
                260,
                150,
                40
        );

        btnProgress.setBounds(
                50,
                310,
                150,
                40
        );

        btnLogout.setBounds(
                250,
                310,
                150,
                40
        );

        // ================= ADD COMPONENT =================

        add(title);

        add(nama);

        add(umur);

        add(tinggi);

        add(berat);

        add(target);

        add(btnMakanan);

        add(btnProgram);

        add(btnProgress);

        add(btnLogout);

        // ================= BUTTON MAKANAN =================

        btnMakanan.addActionListener(e -> {

            try {

                // AMBIL DATA MAKANAN DARI DATABASE
                DAOMakanan dao = new DAOMakanan();

                List<Makanan> listMakanan = dao.getAll();

                // BUKA VIEW KONSUMSI MAKANAN
                new KonsumsiMakanan(
                        listMakanan,
                        member
                );

                dispose();

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Gagal membuka data makanan!"
                );

                ex.printStackTrace();
            }
        });

        // ================= BUTTON PROGRAM =================

        btnProgram.addActionListener(e -> {

            ViewProgram vp =
                    new ViewProgram(member);
            
            new ControllerProgram(vp, member);
            dispose();

        });

        // ================= BUTTON PROGRESS =================

        btnProgress.addActionListener(e -> {

            // KIRIM DATA MEMBER
            new ViewProgress(member);

            dispose();

        });

        // ================= BUTTON LOGOUT =================

        btnLogout.addActionListener(e -> {

            new LoginView();

            dispose();

        });

        setVisible(true);
    }

    // ================= SET DATA MEMBER =================

    public void setDataMember(
            String n,
            int u,
            double t,
            double b,
            double tg
    ) {

        nama.setText(
                "Nama : " + n
        );

        umur.setText(
                "Umur : " + u + " tahun"
        );

        tinggi.setText(
                "Tinggi : " + t + " cm"
        );

        berat.setText(
                "Berat Awal : " + b + " kg"
        );

        target.setText(
                "Target : " + tg + " kg"
        );
    }
}
