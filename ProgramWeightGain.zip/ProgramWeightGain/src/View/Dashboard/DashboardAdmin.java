/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Dashboard;

import View.Login.LoginView;
import View.Makanan.ViewMakanan;
import View.Member.ViewDataMember;
import javax.swing.*;

/**
 *
 * @author Asus
 */

public class DashboardAdmin extends JFrame {

    JLabel title =
            new JLabel("DASHBOARD ADMIN");

    JButton btnMakanan =
            new JButton("Kelola Makanan");

    JButton btnMember =
            new JButton("Data Member");

    JButton btnLogout =
            new JButton("Logout");

    public DashboardAdmin() {

        setTitle("Dashboard Admin");

        setSize(400, 350);

        setLayout(null);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= TITLE =================

        title.setBounds(110, 30, 200, 30);

        // ================= BUTTON =================

        btnMakanan.setBounds(
                100,
                90,
                180,
                40);

        btnMember.setBounds(
                100,
                150,
                180,
                40);

        btnLogout.setBounds(
                100,
                210,
                180,
                40);

        // ================= ADD =================

        add(title);

        add(btnMakanan);

        add(btnMember);

        add(btnLogout);

        // ================= ACTION MAKANAN =================

        btnMakanan.addActionListener(e -> {

            new ViewMakanan();

            dispose();
        });

        // ================= ACTION MEMBER =================

        btnMember.addActionListener(e -> {

            new ViewDataMember();

            dispose();
        });

        // ================= ACTION LOGOUT =================

        btnLogout.addActionListener(e -> {

            new LoginView();

            dispose();
        });

        setVisible(true);
    }
}