/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View.Dashboard;

import Controller.ControllerLogin;
import View.Login.LoginView;
import View.Makanan.ViewMakanan;
import View.Member.ViewDataMember;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 *
 * @author Asus
 */

public class DashboardAdmin extends JFrame {

    public DashboardAdmin() {

        setTitle("Dashboard Admin");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 250, 255));

        JPanel contentPanel = new JPanel(new BorderLayout(20, 20));
        contentPanel.setPreferredSize(new Dimension(500, 420));
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                new EmptyBorder(25, 25, 25, 25)
        ));

        // ===== HEADER =====
        JPanel header = new JPanel(new GridLayout(2, 1, 0, 5));
        header.setBackground(Color.WHITE);

        JLabel lbTitle = new JLabel("DASHBOARD ADMIN", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTitle.setForeground(new Color(33, 150, 243));

        JLabel lbSub = new JLabel("Panel Administrasi Weight Gain Program", SwingConstants.CENTER);
        lbSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbSub.setForeground(new Color(120, 120, 120));

        header.add(lbTitle);
        header.add(lbSub);

        // ===== BUTTON =====
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 0, 15));
        buttonPanel.setBackground(Color.WHITE);

        JButton btnMakanan = new JButton("Kelola Makanan");
        JButton btnMember  = new JButton("Data Member");
        JButton btnLogout  = new JButton("Logout");

        styleBtn(btnMakanan, new Color(33, 150, 243));
        styleBtn(btnMember,  new Color(76, 175, 80));
        styleBtn(btnLogout,  new Color(244, 67, 54));

        buttonPanel.add(btnMakanan);
        buttonPanel.add(btnMember);
        buttonPanel.add(btnLogout);

        contentPanel.add(header, BorderLayout.NORTH);
        contentPanel.add(buttonPanel, BorderLayout.CENTER);

        wrapper.add(contentPanel);
        add(wrapper);

        // ===== ACTION =====
        btnMakanan.addActionListener(e -> {
            new ViewMakanan();
            dispose();
        });

        btnMember.addActionListener(e -> {
            new ViewDataMember();
            dispose();
        });

        // FIX: Logout benar pakai ControllerLogin
        btnLogout.addActionListener(e -> {
            LoginView lv = new LoginView();
            new ControllerLogin(lv);
            dispose();
        });

        setVisible(true);
    }

    private void styleBtn(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setPreferredSize(new Dimension(200, 45));
    }
}