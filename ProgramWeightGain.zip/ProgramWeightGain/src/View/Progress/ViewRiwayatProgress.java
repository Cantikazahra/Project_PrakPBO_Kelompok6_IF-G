/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Progress;

import Model.Users.Member;
import Model.Progress.ProgressBerat;
import Controller.ControllerProgress;
import Controller.ControllerKonsumsi;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * @author Asus
 */
public class ViewRiwayatProgress extends JPanel {

    private ViewProgress parent;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lbSummary;
    private JProgressBar progressBar;

    public ViewRiwayatProgress(ViewProgress parent) {
        this.parent = parent;
        setLayout(new BorderLayout(0, 15));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setPreferredSize(new Dimension(850, 500));

        buildUI();
        loadDataTabel();
    }

    private void buildUI() {
        // Title
        JLabel lbTitle = new JLabel("RIWAYAT PROGRESS", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTitle.setForeground(new Color(33, 150, 243));
        add(lbTitle, BorderLayout.NORTH);

        // Tabel Columns
        String[] columns = {"Tanggal", "Berat Badan", "Kalori", "Protein", "Karbo", "Lemak", "Catatan Kegiatan"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(33, 150, 243));
        table.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(table);
        add(scroll, BorderLayout.CENTER);

        // Bottom Panel untuk Teks Progress & Progress Bar
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBackground(Color.WHITE);

        lbSummary = new JLabel("Berat terbaru: - kg | Progress: - kg | -% target tercapai", SwingConstants.CENTER);
        lbSummary.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbSummary.setAlignmentX(Component.CENTER_ALIGNMENT);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        progressBar.setForeground(new Color(76, 175, 80));
        progressBar.setPreferredSize(new Dimension(500, 20));
        progressBar.setMaximumSize(new Dimension(500, 20));
        progressBar.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnBack = new JButton("Kembali");
        ViewProgress.styleBtn(btnBack, new Color(120, 120, 120));
        btnBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnBack.addActionListener(e -> parent.tampilkanMenu());

        bottomPanel.add(lbSummary);
        bottomPanel.add(Box.createVerticalStrut(10));
        bottomPanel.add(progressBar);
        bottomPanel.add(Box.createVerticalStrut(15));
        bottomPanel.add(btnBack);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void loadDataTabel() {
        tableModel.setRowCount(0);
        Member m = parent.member;

        // Ambil riwayat progress berat dari database
        List<ProgressBerat> listProgress = parent.controller.getProgressMember(m.getId_member());

        if (listProgress == null || listProgress.isEmpty()) {
            lbSummary.setText(String.format("Berat awal: %.1f kg | Belum ada riwayat progress catatan.", m.getBerat_awal()));
            progressBar.setValue(0);
            return;
        }

        double beratTerbaru = m.getBerat_awal();
        boolean beratTerbaruSet = false;

        for (ProgressBerat p : listProgress) {
            String tglStr = p.getTanggal().toString();
            
            // Ambil gizi harian langsung secara real-time dari DAOKonsumsi berdasarkan tanggal baris
            double kalori = parent.controllerKonsumsi.getTotalKalori(m.getId_member(), tglStr);
            double protein = parent.controllerKonsumsi.getTotalProtein(m.getId_member(), tglStr);
            double karbo = parent.controllerKonsumsi.getTotalKarbo(m.getId_member(), tglStr);
            double lemak = parent.controllerKonsumsi.getTotalLemak(m.getId_member(), tglStr);

            // Simpan berat paling atas (terbaru) untuk hitung progress bawah
            if (!beratTerbaruSet) {
                beratTerbaru = p.getBerat_sekarang();
                beratTerbaruSet = true;
            }

            tableModel.addRow(new Object[]{
                tglStr,
                p.getBerat_sekarang() + " kg",
                String.format("%.1f", kalori),
                String.format("%.1f", protein),
                String.format("%.1f", karbo), // Menampilkan karbohidrat hasil hitung DB
                String.format("%.1f", lemak),
                p.getCatatan()
            });
        }

        // ================= HITUNG MATEMATIKA PROGRESS BANYAKNYA BERAT BADAN =================
        double beratAwal = m.getBerat_awal();
        double targetBerat = m.getTarget_berat();
        
        // Rumus selisih penurunan/kenaikan berat badan
        double progressKg = beratAwal - beratTerbaru; 
        double totalTantangan = beratAwal - targetBerat;

        double persentase = 0;
        if (totalTantangan != 0) {
            persentase = (progressKg / totalTantangan) * 100;
            if (persentase < 0) persentase = 0; // proteksi jika berat malah menjauhi target
            if (persentase > 100) persentase = 100; // maksimal 100%
        } else {
            persentase = 100;
        }

        // Update teks label dan isi progress bar bray!
        lbSummary.setText(String.format(
            "Berat terbaru: %.1f kg | Progress: %.1f kg | %.0f%% target tercapai", 
            beratTerbaru, progressKg, persentase
        ));
        progressBar.setValue((int) persentase);
    }
}