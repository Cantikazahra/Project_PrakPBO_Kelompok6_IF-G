/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View.Progress;

import Model.Users.Member;
import Model.Progress.ProgressBerat;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
/**
 * @author Asus
 */

public class ViewRiwayatProgress extends JPanel {

    private ViewProgress parent;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lbSummary;
    private JProgressBar progressBar;
    private JLabel lbLoading;
    private JPanel bottomPanel;

    public ViewRiwayatProgress(ViewProgress parent) {
        this.parent = parent;
        setLayout(new BorderLayout(0, 15));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setPreferredSize(new Dimension(850, 500));

        buildUI();
        loadDataDenganThread();
    }

    private void buildUI() {
        JLabel lbTitle = new JLabel("RIWAYAT PROGRESS", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTitle.setForeground(new Color(33, 150, 243));
        add(lbTitle, BorderLayout.NORTH);

        String[] columns = {"Tanggal", "Berat Badan", "Kalori", "Protein", "Karbo", "Lemak", "Catatan Kegiatan"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(25);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(33, 150, 243));
        table.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(table);
        add(scroll, BorderLayout.CENTER);

        bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBackground(Color.WHITE);

        lbLoading = new JLabel("Memuat data dari database...", SwingConstants.CENTER);
        lbLoading.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lbLoading.setForeground(new Color(33, 150, 243));
        lbLoading.setAlignmentX(Component.CENTER_ALIGNMENT);
        lbLoading.setVisible(true);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setString("Memuat...");
        progressBar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        progressBar.setForeground(new Color(33, 150, 243));
        progressBar.setPreferredSize(new Dimension(500, 22));
        progressBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        progressBar.setAlignmentX(Component.CENTER_ALIGNMENT);
        progressBar.setIndeterminate(true); 

        lbSummary = new JLabel("-", SwingConstants.CENTER);
        lbSummary.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbSummary.setAlignmentX(Component.CENTER_ALIGNMENT);
        lbSummary.setVisible(false);

        JButton btnBack = new JButton("Kembali");
        ViewProgress.styleBtn(btnBack, new Color(120, 120, 120));
        btnBack.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnBack.addActionListener(e -> parent.tampilkanMenu());

        bottomPanel.add(lbLoading);
        bottomPanel.add(Box.createVerticalStrut(8));
        bottomPanel.add(progressBar);
        bottomPanel.add(Box.createVerticalStrut(6));
        bottomPanel.add(lbSummary);
        bottomPanel.add(Box.createVerticalStrut(15));
        bottomPanel.add(btnBack);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void loadDataDenganThread() {

        SwingWorker<Void, Object[]> worker = new SwingWorker<Void, Object[]>() {

            double beratTerbaru = 0;
            double persentase   = 0;
            double progressKg   = 0;
            boolean adaData     = false;

            @Override
            protected Void doInBackground() throws Exception {
                Thread.sleep(1500);

                Member m = parent.member;
                List<ProgressBerat> listProgress =
                        parent.controller.getProgressMember(m.getId_member());

                if (listProgress == null || listProgress.isEmpty()) {
                    beratTerbaru = m.getBerat_awal();
                    return null;
                }

                adaData = true;
                boolean beratTerbaruSet = false;

                for (ProgressBerat p : listProgress) {
                    String tglStr = p.getTanggal().toString();

                    double kalori  = parent.controllerKonsumsi.getTotalKalori(m.getId_member(), tglStr);
                    double protein = parent.controllerKonsumsi.getTotalProtein(m.getId_member(), tglStr);
                    double karbo   = parent.controllerKonsumsi.getTotalKarbo(m.getId_member(), tglStr);
                    double lemak   = parent.controllerKonsumsi.getTotalLemak(m.getId_member(), tglStr);

                    if (!beratTerbaruSet) {
                        beratTerbaru = p.getBerat_sekarang();
                        beratTerbaruSet = true;
                    }

                    publish(new Object[]{
                        tglStr,
                        p.getBerat_sekarang() + " kg",
                        String.format("%.1f", kalori),
                        String.format("%.1f", protein),
                        String.format("%.1f", karbo),
                        String.format("%.1f", lemak),
                        p.getCatatan()
                    });
                }

                double beratAwal = m.getBerat_awal();
                double targetBerat = m.getTarget_berat();
                progressKg = beratTerbaru - beratAwal;
                double totalTantangan = targetBerat - beratAwal;

                if (totalTantangan != 0) {
                    persentase = (progressKg / totalTantangan) * 100;
                    if (persentase < 0) persentase = 0;
                    if (persentase > 100) persentase = 100;
                } else {
                    persentase = 100;
                }

                return null;
            }

            @Override
            protected void process(List<Object[]> chunks) {
                for (Object[] baris : chunks) {
                    tableModel.addRow(baris);
                }
            }

            @Override
            protected void done() {
                try {
                    get();

                    Member m = parent.member;

                    progressBar.setIndeterminate(false);
                    progressBar.setForeground(new Color(76, 175, 80));

                    if (!adaData) {
                        progressBar.setValue(0);
                        progressBar.setString("0%");
                        lbSummary.setText(String.format(
                            "Berat awal: %.1f kg | Belum ada riwayat progress.", m.getBerat_awal()
                        ));
                    } else {
                        progressBar.setValue((int) persentase);
                        progressBar.setString(String.format("%.0f%%", persentase));
                        lbSummary.setText(String.format(
                            "Berat terbaru: %.1f kg | Progress: %.1f kg | %.0f%% target tercapai",
                            beratTerbaru, progressKg, persentase
                        ));
                    }

                    lbLoading.setVisible(false);
                    lbSummary.setVisible(true);

                } catch (Exception ex) {
                    progressBar.setIndeterminate(false);
                    lbLoading.setText("Gagal memuat data: " + ex.getMessage());
                    lbLoading.setForeground(Color.RED);
                }
            }
        };

        worker.execute();
    }
}