/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Progress;

import javax.swing.*;
import java.awt.*;

import Model.Users.Member;
import Controller.ControllerProgress;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 *
 * @author Asus
 */

public class ViewProgress extends JFrame {

    // ================= DATA MEMBER =================
    Member member;

    // ================= COMPONENT =================
    JLabel title = new JLabel("PROGRESS MEMBER");

    JLabel lbTanggal = new JLabel("Tanggal");
    JLabel lbBerat = new JLabel("Berat Sekarang");
    JLabel lbKalori = new JLabel("Total Kalori Hari Ini");
    JLabel lbCatatan = new JLabel("Catatan");

    JLabel lbInfo = new JLabel();

    JTextField tfTanggal = new JTextField();
    JTextField tfBerat = new JTextField();
    JTextField tfKalori = new JTextField();

    JTextArea taCatatan = new JTextArea();
    JScrollPane scroll = new JScrollPane(taCatatan);

    JButton btnSimpan = new JButton("Simpan");
    JButton btnBack = new JButton("Back");

    ControllerProgress controller;

    // ================= CONSTRUCTOR =================
    public ViewProgress(Member member) {

        this.member = member;

        controller = new ControllerProgress();

        // ================= FRAME =================
        setTitle("Progress Member");
        setSize(550, 500);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        getContentPane().setBackground(new Color(245, 250, 255));

        // ================= TITLE =================
        title.setBounds(120, 20, 320, 35);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));

        // ================= LABEL =================
        lbTanggal.setBounds(40, 90, 180, 25);
        lbBerat.setBounds(40, 140, 180, 25);
        lbKalori.setBounds(40, 190, 180, 25);
        lbCatatan.setBounds(40, 240, 180, 25);

        lbBerat.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbKalori.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbCatatan.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbTanggal.setFont(new Font("Segoe UI", Font.BOLD, 14));

        // ================= INPUT =================
        tfTanggal.setBounds(220, 90, 220, 30);
        tfBerat.setBounds(220, 140, 220, 30);
        tfKalori.setBounds(220, 190, 220, 30);

        scroll.setBounds(220, 240, 220, 100);

        tfBerat.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tfKalori.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tfTanggal.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        // ================= FORMAT TANGGAL =================
        DateTimeFormatter format =
                DateTimeFormatter.ofPattern(
                        "dd MMMM yyyy",
                        new Locale("id", "ID")
                );

        // ================= AUTO TANGGAL =================
        tfTanggal.setText(
                LocalDate.now().format(format)
        );

        tfTanggal.setEditable(false);

        // ================= TEXT AREA =================
        taCatatan.setLineWrap(true);
        taCatatan.setWrapStyleWord(true);

        // ================= INFO TARGET =================
        lbInfo.setBounds(40, 360, 450, 25);
        lbInfo.setFont(new Font("Segoe UI", Font.BOLD, 13));

        double selisih =
                member.getTarget_berat()
                - member.getBerat_awal();

        lbInfo.setText(
                "Target Berat : "
                + member.getTarget_berat()
                + " kg | Selisih : "
                + selisih
                + " kg"
        );

        // ================= BUTTON =================
        btnSimpan.setBounds(120, 400, 120, 40);
        btnBack.setBounds(280, 400, 120, 40);

        btnSimpan.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));

        // ================= ACTION SIMPAN =================
        btnSimpan.addActionListener(e -> {

            try {

                // VALIDASI KOSONG
                if (tfBerat.getText().trim().isEmpty()
                        || tfKalori.getText().trim().isEmpty()) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Semua field wajib diisi!"
                    );

                    return;
                }

                double berat = Double.parseDouble(
                        tfBerat.getText().trim().replace(",", ".")
                );

                double kalori = Double.parseDouble(
                        tfKalori.getText().trim().replace(",", ".")
                );

                // VALIDASI ANGKA NEGATIF
                if (berat <= 0 || kalori <= 0) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Input harus lebih dari 0!"
                    );

                    return;
                }

                // FORMAT TANGGAL UNTUK DATABASE
                String tanggalDB =
                        LocalDate.now().toString();

                boolean success =
                        controller.insertProgress(
                                member.getId_member(),
                                tanggalDB,
                                berat,
                                kalori,
                                taCatatan.getText()
                        );

                if (success) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Progress berhasil disimpan!"
                    );

                    tfBerat.setText("");
                    tfKalori.setText("");
                    taCatatan.setText("");
                }

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Berat dan kalori harus angka!"
                );
            }
        });

        // ================= ACTION BACK =================
        btnBack.addActionListener(e -> {

            new View.Dashboard.DashboardMember(member);

            dispose();
        });

        // ================= ADD COMPONENT =================
        add(title);

        add(lbTanggal);
        add(lbBerat);
        add(lbKalori);
        add(lbCatatan);

        add(tfTanggal);
        add(tfBerat);
        add(tfKalori);

        add(scroll);

        add(lbInfo);

        add(btnSimpan);
        add(btnBack);

        // ================= SHOW FRAME =================
        setVisible(true);
    }
}