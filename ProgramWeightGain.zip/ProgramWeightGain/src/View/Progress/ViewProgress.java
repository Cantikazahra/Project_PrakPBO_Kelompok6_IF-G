/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Progress;

import javax.swing.*;
import java.awt.*;
import Model.Users.Member;
import Controller.ControllerProgress;
import Controller.ControllerKonsumsi;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 *
 * @author Asus
 */

public class ViewProgress extends JFrame {

    Member member;
    ControllerProgress controller;
    ControllerKonsumsi controllerKonsumsi;

    DateTimeFormatter fmtTampil =
            DateTimeFormatter.ofPattern("d MMMM yyyy", new Locale("id", "ID"));
    DateTimeFormatter fmtDB =
            DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public ViewProgress(Member member) {
        this.member = member;
        controller         = new ControllerProgress();
        controllerKonsumsi = new ControllerKonsumsi();
        tampilkanMenu();
    }

    void tampilkanMenu() {
        getContentPane().removeAll();
        setTitle("Progress Member");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 250, 255));
        wrapper.add(new ViewProgressMenu(this));

        getContentPane().add(wrapper);
        setVisible(true);
        revalidate();
        repaint();
    }

    void halamanCatatProgress() {
        getContentPane().removeAll();
        setTitle("Catat Progress");

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 250, 255));
        wrapper.add(new ViewCatatProgress(this));

        getContentPane().add(wrapper);
        revalidate();
        repaint();
    }

    void halamanLihatProgress() {
        getContentPane().removeAll();
        setTitle("Riwayat Progress");

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(245, 250, 255));
        wrapper.add(new ViewRiwayatProgress(this));

        getContentPane().add(wrapper);
        revalidate();
        repaint();
    }

    static void styleBtn(JButton b, Color c) {
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(220, 42));
    }
}
