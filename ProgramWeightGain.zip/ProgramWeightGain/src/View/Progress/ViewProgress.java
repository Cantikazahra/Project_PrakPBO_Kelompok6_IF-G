/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Progress;

import javax.swing.*;
import java.awt.*;
import Model.Users.Member;
import Controller.ControllerProgress;

/**
 *
 * @author Asus
 */

public class ViewProgress extends JFrame {

    // ================= DATA MEMBER =================
    Member member;

    // ================= COMPONENT =================
    JLabel title = new JLabel("PROGRESS MEMBER");

    JLabel lbBerat = new JLabel("Berat Sekarang");
    JLabel lbKalori = new JLabel("Total Kalori Hari Ini");
    JLabel lbCatatan = new JLabel("Catatan");

    JTextField tfBerat = new JTextField();
    JTextField tfKalori = new JTextField();

    JTextArea taCatatan = new JTextArea();
    JScrollPane scroll = new JScrollPane(taCatatan);

    JButton btnSimpan = new JButton("Simpan");
    JButton btnBack = new JButton("Back");

    ControllerProgress controller;

    // ================= CONSTRUCTOR =================
    public ViewProgress(Member member) {

        this.member = member;

        controller = new ControllerProgress();

        setTitle("Progress Member");
        setSize(500, 450);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        getContentPane().setBackground(new Color(245, 250, 255));

        // ================= TITLE =================
        title.setBounds(130, 20, 250, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));

        // ================= LABEL =================
        lbBerat.setBounds(40, 100, 180, 25);
        lbKalori.setBounds(40, 150, 180, 25);
        lbCatatan.setBounds(40, 200, 180, 25);

        // ================= INPUT =================
        tfBerat.setBounds(220, 100, 180, 30);
        tfKalori.setBounds(220, 150, 180, 30);
        scroll.setBounds(220, 200, 180, 80);

        // ================= BUTTON =================
        btnSimpan.setBounds(120, 330, 100, 40);
        btnBack.setBounds(250, 330, 100, 40);

        // ================= ACTION SIMPAN =================
        btnSimpan.addActionListener(e -> {

            try {

                double berat = Double.parseDouble(
                        tfBerat.getText().trim().replace(",", ".")
                );

                double kalori = Double.parseDouble(
                        tfKalori.getText().trim().replace(",", ".")
                );

                boolean success = controller.insertProgress(
                        member.getId_member(),
                        java.time.LocalDate.now().toString(),
                        berat,
                        kalori,
                        taCatatan.getText()
                );

                if (success) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Progress berhasil disimpan!"
                    );

                    tfBerat.setText("");
                    tfKalori.setText("");
                    taCatatan.setText("");
                }

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Input tidak valid!"
                );

                ex.printStackTrace();
            }
        });

        // ================= ACTION BACK =================
        btnBack.addActionListener(e -> {

            new View.Dashboard.DashboardMember(member);
            dispose();
        });

        // ================= ADD COMPONENT =================
        add(title);

        add(lbBerat);
        add(lbKalori);
        add(lbCatatan);

        add(tfBerat);
        add(tfKalori);
        add(scroll);

        add(btnSimpan);
        add(btnBack);

        setVisible(true);
    }
}
