/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Progress;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Asus
 */

class ViewProgressMenu extends JPanel {

    ViewProgressMenu(ViewProgress frame) {
        setLayout(new BorderLayout(0, 20));
        setPreferredSize(new Dimension(420, 340));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
        ));

        JLabel lbTitle = new JLabel("PROGRESS MEMBER", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbTitle.setForeground(new Color(33, 150, 243));
        add(lbTitle, BorderLayout.NORTH);

        JLabel lbHalo = new JLabel("Halo, " + frame.member.getNama() + "!");
        lbHalo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbHalo.setForeground(new Color(76, 175, 80));

        JButton btnCatat = new JButton("Catat Progress Hari Ini");
        JButton btnLihat = new JButton("Lihat Riwayat Progress");
        JButton btnBack  = new JButton("Kembali");

        ViewProgress.styleBtn(btnCatat, new Color(33, 150, 243));
        ViewProgress.styleBtn(btnLihat, new Color(76, 175, 80));
        ViewProgress.styleBtn(btnBack,  new Color(120, 120, 120));

        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(Color.WHITE);

        lbHalo.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCatat.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLihat.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnBack.setAlignmentX(Component.CENTER_ALIGNMENT);

        for (JButton b : new JButton[]{btnCatat, btnLihat, btnBack}) {
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        }

        center.add(lbHalo);
        center.add(Box.createVerticalStrut(18));
        center.add(btnCatat);
        center.add(Box.createVerticalStrut(10));
        center.add(btnLihat);
        center.add(Box.createVerticalStrut(10));
        center.add(btnBack);

        add(center, BorderLayout.CENTER);

        btnCatat.addActionListener(e -> frame.halamanCatatProgress());
        btnLihat.addActionListener(e -> frame.halamanLihatProgress());
        btnBack.addActionListener(e -> {
            new View.Dashboard.DashboardMember(frame.member);
            frame.dispose();
        });
    }
}
