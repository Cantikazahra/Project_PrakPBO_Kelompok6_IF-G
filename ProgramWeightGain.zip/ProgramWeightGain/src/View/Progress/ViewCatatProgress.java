/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.Progress;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.LocalDate;

/**
 *
 * @author Asus
 */
class ViewCatatProgress extends JPanel {

    ViewCatatProgress(ViewProgress frame) {
        setLayout(new BorderLayout(0, 15));
        setPreferredSize(new Dimension(460, 420));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(25, 30, 25, 30)
        ));

        JLabel lbTitle = new JLabel("CATAT PROGRESS", SwingConstants.CENTER);
        lbTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbTitle.setForeground(new Color(33, 150, 243));
        add(lbTitle, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(8, 8, 8, 8);
        gc.fill   = GridBagConstraints.HORIZONTAL;

        Font bold  = new Font("Segoe UI", Font.BOLD,   13);
        Font plain = new Font("Segoe UI", Font.PLAIN,  13);
        Font small = new Font("Segoe UI", Font.ITALIC, 10);

        JLabel lbTanggal = new JLabel("Tanggal");
        JTextField tfTanggal = new JTextField(LocalDate.now().format(frame.fmtTampil));

        JLabel lbBerat = new JLabel("Berat Sekarang");
        JTextField tfBerat = new JTextField();

        JLabel lbKalori = new JLabel("Total Kalori Harian");
        JTextField tfKalori = new JTextField();
        tfKalori.setEditable(false);
        tfKalori.setBackground(new Color(245, 245, 245));

        JLabel lbHint = new JLabel("Kalori otomatis dari konsumsi tanggal tersebut");
        lbHint.setFont(small);
        lbHint.setForeground(new Color(120, 120, 120));

        JLabel lbCatatan = new JLabel("Catatan Kegiatan");
        JTextArea taCatatan = new JTextArea(3, 20);
        taCatatan.setLineWrap(true);
        taCatatan.setWrapStyleWord(true);
        JScrollPane sp = new JScrollPane(taCatatan);

        for (JLabel lb : new JLabel[]{lbTanggal, lbBerat, lbKalori, lbCatatan}) lb.setFont(bold);
        tfTanggal.setFont(plain);
        tfBerat.setFont(plain);
        tfKalori.setFont(plain);
        taCatatan.setFont(plain);

        gc.gridx = 0; gc.gridy = 0; form.add(lbTanggal, gc);
        gc.gridx = 1; form.add(tfTanggal, gc);
        gc.gridx = 0; gc.gridy = 1; form.add(lbBerat, gc);
        gc.gridx = 1; form.add(tfBerat, gc);
        gc.gridx = 0; gc.gridy = 2; form.add(lbKalori, gc);
        gc.gridx = 1; form.add(tfKalori, gc);
        gc.gridx = 1; gc.gridy = 3; form.add(lbHint, gc);
        gc.gridx = 0; gc.gridy = 4; form.add(lbCatatan, gc);
        gc.gridx = 1; form.add(sp, gc);

        add(form, BorderLayout.CENTER);

        JButton btnSimpan = new JButton("Simpan");
        JButton btnBack = new JButton("Back");
        ViewProgress.styleBtn(btnSimpan, new Color(33, 150, 243));
        ViewProgress.styleBtn(btnBack, new Color(120, 120, 120));

        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 12, 0));
        btnPanel.setBackground(Color.WHITE);
        btnPanel.add(btnSimpan);
        btnPanel.add(btnBack);
        add(btnPanel, BorderLayout.SOUTH);

        Runnable updateKaloriOtomatis = () -> {
            try {
                String inputTanggal = tfTanggal.getText().trim();
                
                if (inputTanggal.contains("mei")) inputTanggal = inputTanggal.replace("mei", "Mei");
                if (inputTanggal.contains("juni")) inputTanggal = inputTanggal.replace("juni", "Juni");
                
                LocalDate tgl = LocalDate.parse(inputTanggal, frame.fmtTampil);
                
                double k = frame.controllerKonsumsi.getTotalKalori(
                        frame.member.getId_member(), tgl.format(frame.fmtDB));
                tfKalori.setText(String.format("%.0f", k));
            } catch (Exception ex) {
                tfKalori.setText("0");
            }
        };

        updateKaloriOtomatis.run();

        tfTanggal.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { 
                updateKaloriOtomatis.run(); 
            }
            @Override
            public void removeUpdate(DocumentEvent e) { 
                updateKaloriOtomatis.run(); 
            }
            @Override
            public void changedUpdate(DocumentEvent e) { 
                updateKaloriOtomatis.run(); 
            }
        });

        tfTanggal.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                updateKaloriOtomatis.run();
            }
        });

        tfTanggal.addActionListener(e -> updateKaloriOtomatis.run());

        btnSimpan.addActionListener(e -> {
            try {
                LocalDate tanggal;
                try {
                    String inputTanggal = tfTanggal.getText().trim();
                    if (inputTanggal.contains("mei")) inputTanggal = inputTanggal.replace("mei", "Mei");
                    if (inputTanggal.contains("juni")) inputTanggal = inputTanggal.replace("juni", "Juni");
                    
                    tanggal = LocalDate.parse(inputTanggal, frame.fmtTampil);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null,
                            "Format tanggal salah!\nContoh: 30 Mei 2026");
                    return;
                }
                
                if (tfBerat.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Kolom Berat Sekarang tidak boleh kosong!");
                    return;
                }

                double berat  = Double.parseDouble(tfBerat.getText().trim());
                double kalori = Double.parseDouble(tfKalori.getText().trim());

                boolean ok = frame.controller.insertProgress(
                        frame.member.getId_member(),
                        tanggal.format(frame.fmtDB),
                        berat, kalori, taCatatan.getText()
                );
                
                if (ok) {
                    JOptionPane.showMessageDialog(null, "Progress berhasil disimpan!");
                    tfBerat.setText("");
                    taCatatan.setText("");
                    updateKaloriOtomatis.run(); 
                } else {
                    JOptionPane.showMessageDialog(null, "Gagal menyimpan!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Input berat harus angka!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + ex.getMessage());
            }
        });

        btnBack.addActionListener(e -> frame.tampilkanMenu());
    }
}