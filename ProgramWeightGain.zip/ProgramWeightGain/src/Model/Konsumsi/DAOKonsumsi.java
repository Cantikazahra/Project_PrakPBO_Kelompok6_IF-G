/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Konsumsi;

import Model.Connector;
import java.sql.*;

/**
 *
 * @author Asus
 */
public class DAOKonsumsi {

    private Connection connection;

    public DAOKonsumsi() {
        connection = Connector.getConnection();
    }

    public void insert(Model.Konsumsi.Konsumsi k) {
        String query = "INSERT INTO konsumsi_makanan (id_member, id_makanan, tanggal, jumlah_porsi, "
                     + "total_kalori, total_protein, total_karbo, total_lemak) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, k.getId_member());
            ps.setInt(2, k.getId_makanan());
            ps.setDate(3, k.getTanggal());
            ps.setDouble(4, k.getJumlah_porsi());
            
            try {
                ps.setDouble(5, (double) k.getClass().getMethod("getTotal_kalori").invoke(k));
                ps.setDouble(6, (double) k.getClass().getMethod("getTotal_protein").invoke(k));
                ps.setDouble(7, (double) k.getClass().getMethod("getTotal_karbo").invoke(k));
                ps.setDouble(8, (double) k.getClass().getMethod("getTotal_lemak").invoke(k));
            } catch (Exception e) {
                ps.setDouble(5, 0); ps.setDouble(6, 0); ps.setDouble(7, 0); ps.setDouble(8, 0);
            }
            
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Gagal insert konsumsi: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public double getTotalKalori(int id_member, String tanggal) {
        double total = 0;
        String query = "SELECT SUM(total_kalori) AS total FROM konsumsi_makanan WHERE id_member = ? AND tanggal = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id_member); ps.setString(2, tanggal);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) total = rs.getDouble("total"); }
        } catch (Exception e) { e.printStackTrace(); }
        return total;
    }

    public double getTotalProtein(int id_member, String tanggal) {
        double total = 0;
        String query = "SELECT SUM(total_protein) AS total FROM konsumsi_makanan WHERE id_member = ? AND tanggal = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id_member); ps.setString(2, tanggal);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) total = rs.getDouble("total"); }
        } catch (Exception e) { e.printStackTrace(); }
        return total;
    }

    public double getTotalKarbo(int id_member, String tanggal) {
        double total = 0;
        String query = "SELECT SUM(total_karbo) AS total FROM konsumsi_makanan WHERE id_member = ? AND tanggal = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id_member); ps.setString(2, tanggal);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) total = rs.getDouble("total"); }
        } catch (Exception e) { e.printStackTrace(); }
        return total;
    }

    public double getTotalLemak(int id_member, String tanggal) {
        double total = 0;
        String query = "SELECT SUM(total_lemak) AS total FROM konsumsi_makanan WHERE id_member = ? AND tanggal = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id_member); ps.setString(2, tanggal);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) total = rs.getDouble("total"); }
        } catch (Exception e) { e.printStackTrace(); }
        return total;
    }
}