/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Konsumsi;

import Model.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Asus
 */

public class DAOKonsumsi implements InterfaceDAOKonsumsi {

    Connection conn;

    public DAOKonsumsi() {

        conn = Connector.getConnection();
    }

    // ================= INSERT =================

    @Override
    public boolean insert(
            Konsumsi konsumsi) {

        try {

            String sql =
                    "INSERT INTO konsumsi_makanan "
                    + "(id_member, id_makanan, tanggal, jumlah_porsi, total_kalori, total_protein, total_karbo, total_lemak) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    konsumsi.getId_member());

            ps.setInt(
                    2,
                    konsumsi.getId_makanan());

            ps.setDate(
                    3,
                    konsumsi.getTanggal());

            ps.setDouble(
                    4,
                    konsumsi.getJumlah_porsi());

            ps.setDouble(
                    5,
                    konsumsi.getTotal_kalori());

            ps.setDouble(
                    6,
                    konsumsi.getTotal_protein());

            ps.setDouble(
                    7,
                    konsumsi.getTotal_karbo());

            ps.setDouble(
                    8,
                    konsumsi.getTotal_lemak());

            ps.executeUpdate();

            return true;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    // ================= UPDATE =================

    @Override
    public boolean update(
            Konsumsi konsumsi) {

        try {

            String sql =
                    "UPDATE konsumsi_makanan SET "
                    + "id_member=?, "
                    + "id_makanan=?, "
                    + "tanggal=?, "
                    + "jumlah_porsi=?, "
                    + "total_kalori=?, "
                    + "total_protein=?, "
                    + "total_karbo=?, "
                    + "total_lemak=? "
                    + "WHERE id_konsumsi=?";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    konsumsi.getId_member());

            ps.setInt(
                    2,
                    konsumsi.getId_makanan());

            ps.setDate(
                    3,
                    konsumsi.getTanggal());

            ps.setDouble(
                    4,
                    konsumsi.getJumlah_porsi());

            ps.setDouble(
                    5,
                    konsumsi.getTotal_kalori());

            ps.setDouble(
                    6,
                    konsumsi.getTotal_protein());

            ps.setDouble(
                    7,
                    konsumsi.getTotal_karbo());

            ps.setDouble(
                    8,
                    konsumsi.getTotal_lemak());

            ps.setInt(
                    9,
                    konsumsi.getId_konsumsi());

            ps.executeUpdate();

            return true;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    // ================= DELETE =================

    @Override
    public boolean delete(
            int id_konsumsi) {

        try {

            String sql =
                    "DELETE FROM konsumsi_makanan "
                    + "WHERE id_konsumsi=?";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    id_konsumsi);

            ps.executeUpdate();

            return true;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    // ================= GET ALL =================

    @Override
    public List<Konsumsi> getAll() {

        List<Konsumsi> list =
                new ArrayList<>();

        try {

            String sql =
                    "SELECT * FROM konsumsi_makanan";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while (rs.next()) {

                Konsumsi k =
                        new Konsumsi();

                k.setId_konsumsi(
                        rs.getInt("id_konsumsi"));

                k.setId_member(
                        rs.getInt("id_member"));

                k.setId_makanan(
                        rs.getInt("id_makanan"));

                k.setTanggal(
                        rs.getDate("tanggal"));

                k.setJumlah_porsi(
                        rs.getDouble("jumlah_porsi"));

                k.setTotal_kalori(
                        rs.getDouble("total_kalori"));

                k.setTotal_protein(
                        rs.getDouble("total_protein"));

                k.setTotal_karbo(
                        rs.getDouble("total_karbo"));

                k.setTotal_lemak(
                        rs.getDouble("total_lemak"));

                list.add(k);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return list;
    }

    // ================= GET BY MEMBER =================

    @Override
    public List<Konsumsi> getByMember(
            int id_member) {

        List<Konsumsi> list =
                new ArrayList<>();

        try {

            String sql =
                    "SELECT * FROM konsumsi_makanan "
                    + "WHERE id_member=?";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    id_member);

            ResultSet rs =
                    ps.executeQuery();

            while (rs.next()) {

                Konsumsi k =
                        new Konsumsi();

                k.setId_konsumsi(
                        rs.getInt("id_konsumsi"));

                k.setId_member(
                        rs.getInt("id_member"));

                k.setId_makanan(
                        rs.getInt("id_makanan"));

                k.setTanggal(
                        rs.getDate("tanggal"));

                k.setJumlah_porsi(
                        rs.getDouble("jumlah_porsi"));

                k.setTotal_kalori(
                        rs.getDouble("total_kalori"));

                k.setTotal_protein(
                        rs.getDouble("total_protein"));

                k.setTotal_karbo(
                        rs.getDouble("total_karbo"));

                k.setTotal_lemak(
                        rs.getDouble("total_lemak"));

                list.add(k);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return list;
    }

    // ================= TOTAL KALORI =================

    @Override
    public double getTotalKaloriHariIni(
            int id_member) {

        double total = 0;

        try {

            String sql =
                    "SELECT SUM(total_kalori) AS total "
                    + "FROM konsumsi_makanan "
                    + "WHERE id_member=? "
                    + "AND tanggal = CURDATE()";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    id_member);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                total =
                        rs.getDouble("total");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return total;
    }

    // ================= TOTAL PROTEIN =================

    @Override
    public double getTotalProteinHariIni(
            int id_member) {

        double total = 0;

        try {

            String sql =
                    "SELECT SUM(total_protein) AS total "
                    + "FROM konsumsi_makanan "
                    + "WHERE id_member=? "
                    + "AND tanggal = CURDATE()";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    id_member);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                total =
                        rs.getDouble("total");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return total;
    }

    // ================= TOTAL KARBO =================

    @Override
    public double getTotalKarboHariIni(
            int id_member) {

        double total = 0;

        try {

            String sql =
                    "SELECT SUM(total_karbo) AS total "
                    + "FROM konsumsi_makanan "
                    + "WHERE id_member=? "
                    + "AND tanggal = CURDATE()";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    id_member);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                total =
                        rs.getDouble("total");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return total;
    }

    // ================= TOTAL LEMAK =================

    @Override
    public double getTotalLemakHariIni(
            int id_member) {

        double total = 0;

        try {

            String sql =
                    "SELECT SUM(total_lemak) AS total "
                    + "FROM konsumsi_makanan "
                    + "WHERE id_member=? "
                    + "AND tanggal = CURDATE()";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(
                    1,
                    id_member);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                total =
                        rs.getDouble("total");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return total;
    }
}