/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Konsumsi;

import java.util.List;

/**
 *
 * @author Asus
 */

public interface InterfaceDAOKonsumsi {

    // ================= INSERT =================

    public boolean insert(
            Konsumsi konsumsi);

    // ================= UPDATE =================

    public boolean update(
            Konsumsi konsumsi);

    // ================= DELETE =================

    public boolean delete(
            int id_konsumsi);

    // ================= GET =================

    public List<Konsumsi> getAll();

    public List<Konsumsi> getByMember(
            int id_member);

    // ================= TOTAL =================

    public double getTotalKaloriHariIni(
            int id_member);

    public double getTotalProteinHariIni(
            int id_member);

    public double getTotalKarboHariIni(
            int id_member);

    public double getTotalLemakHariIni(
            int id_member);
}