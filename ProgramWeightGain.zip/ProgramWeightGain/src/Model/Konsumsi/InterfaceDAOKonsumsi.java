package Model.Konsumsi;

import java.util.List;

public interface InterfaceDAOKonsumsi {

    public boolean insert(Konsumsi konsumsi);
    public boolean update(Konsumsi konsumsi);
    public boolean delete(int id_konsumsi);

    public List<Konsumsi> getAll();
    public List<Konsumsi> getByMember(int id_member);

    public double getTotalKaloriHariIni(int id_member);
    public double getTotalProteinHariIni(int id_member);
    public double getTotalKarboHariIni(int id_member);
    public double getTotalLemakHariIni(int id_member);

    public double getTotalKaloriByTanggal(int id_member, String tanggal);
    public double getTotalProteinByTanggal(int id_member, String tanggal);
    public double getTotalKarboByTanggal(int id_member, String tanggal);
    public double getTotalLemakByTanggal(int id_member, String tanggal);
}
