/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Konsumsi;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Asus
 */

public class ModelTableKonsumsi
        extends AbstractTableModel {

    List<Konsumsi> listKonsumsi;

    String[] kolom = {
        "ID",
        "ID Member",
        "ID Makanan",
        "Tanggal",
        "Jumlah Porsi",
        "Kalori",
        "Protein",
        "Karbo",
        "Lemak"
    };

    public ModelTableKonsumsi(
            List<Konsumsi> listKonsumsi) {

        this.listKonsumsi =
                listKonsumsi;
    }

    // ================= JUMLAH BARIS =================

    @Override
    public int getRowCount() {

        return listKonsumsi.size();
    }

    // ================= JUMLAH KOLOM =================

    @Override
    public int getColumnCount() {

        return kolom.length;
    }

    // ================= NAMA KOLOM =================

    @Override
    public String getColumnName(
            int column) {

        return kolom[column];
    }

    // ================= ISI DATA =================

    @Override
    public Object getValueAt(
            int rowIndex,
            int columnIndex) {

        Konsumsi konsumsi =
                listKonsumsi.get(rowIndex);

        switch (columnIndex) {

            case 0:
                return konsumsi.getId_konsumsi();

            case 1:
                return konsumsi.getId_member();

            case 2:
                return konsumsi.getId_makanan();

            case 3:
                return konsumsi.getTanggal();

            case 4:
                return konsumsi.getJumlah_porsi();

            case 5:
                return konsumsi.getTotal_kalori();

            case 6:
                return konsumsi.getTotal_protein();

            case 7:
                return konsumsi.getTotal_karbo();

            case 8:
                return konsumsi.getTotal_lemak();

            default:
                return null;
        }
    }
}
