/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Konsumsi;
import java.sql.Date;
/**
 *
 * @author Asus
 */

public class Konsumsi {

    private int id_konsumsi;

    private int id_member;

    private int id_makanan;

    private Date tanggal;

    private double jumlah_porsi;

    private double total_kalori;

    private double total_protein;

    private double total_karbo;

    private double total_lemak;

    // ================= CONSTRUCTOR =================

    public Konsumsi() {

    }

    public Konsumsi(
            int id_konsumsi,
            int id_member,
            int id_makanan,
            Date tanggal,
            double jumlah_porsi,
            double total_kalori,
            double total_protein,
            double total_karbo,
            double total_lemak) {

        this.id_konsumsi = id_konsumsi;

        this.id_member = id_member;

        this.id_makanan = id_makanan;

        this.tanggal = tanggal;

        this.jumlah_porsi = jumlah_porsi;

        this.total_kalori = total_kalori;

        this.total_protein = total_protein;

        this.total_karbo = total_karbo;

        this.total_lemak = total_lemak;
    }

    // ================= GETTER SETTER =================

    public int getId_konsumsi() {

        return id_konsumsi;
    }

    public void setId_konsumsi(int id_konsumsi) {

        this.id_konsumsi = id_konsumsi;
    }

    public int getId_member() {

        return id_member;
    }

    public void setId_member(int id_member) {

        this.id_member = id_member;
    }

    public int getId_makanan() {

        return id_makanan;
    }

    public void setId_makanan(int id_makanan) {

        this.id_makanan = id_makanan;
    }

    public Date getTanggal() {

        return tanggal;
    }

    public void setTanggal(Date tanggal) {

        this.tanggal = tanggal;
    }

    public double getJumlah_porsi() {

        return jumlah_porsi;
    }

    public void setJumlah_porsi(double jumlah_porsi) {

        this.jumlah_porsi = jumlah_porsi;
    }

    public double getTotal_kalori() {

        return total_kalori;
    }

    public void setTotal_kalori(double total_kalori) {

        this.total_kalori = total_kalori;
    }

    public double getTotal_protein() {

        return total_protein;
    }

    public void setTotal_protein(double total_protein) {

        this.total_protein = total_protein;
    }

    public double getTotal_karbo() {

        return total_karbo;
    }

    public void setTotal_karbo(double total_karbo) {

        this.total_karbo = total_karbo;
    }

    public double getTotal_lemak() {

        return total_lemak;
    }

    public void setTotal_lemak(double total_lemak) {

        this.total_lemak = total_lemak;
    }
}
