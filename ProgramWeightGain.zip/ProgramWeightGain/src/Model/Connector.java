/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Asus
 */
public class Connector {
    private static Connection connection;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                String url = "jdbc:mysql://localhost:3306/weightgain_db";
                String user = "root";
                String password = "";

                Class.forName("com.mysql.cj.jdbc.Driver");

                connection = DriverManager.getConnection(url, user, password);
                System.out.println("Koneksi Baru Berhasil Dibuat");
            } else {
                System.out.println("Menggunakan Koneksi yang Sudah Ada");
            }
        } catch (Exception e) {
            System.out.println("Koneksi Gagal : " + e.getMessage());
        }

        return connection;
    }
}