/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Users;

/**
 *
 * @author Asus
 */
public class Admin extends User {

    @Override
    public void displayRole() {
        System.out.println("Dashboard Admin");
    }
}
