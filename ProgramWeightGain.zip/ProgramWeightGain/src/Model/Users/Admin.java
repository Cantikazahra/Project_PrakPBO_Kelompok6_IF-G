/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Users;
import View.Dashboard.DashboardAdmin;
/**
 *
 * @author Asus
 */

public class Admin extends User {

    @Override
    public String displayRole() {
        return "Admin";
    }

    @Override
    public void openDashboard() {
        new DashboardAdmin();
    }
}