/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Users;
import View.Dashboard.DashboardMember;

/**
 *
 * @author Asus
 */

public class Member extends User {

    private int id_member;
    private String nama;
    private int umur;
    private double tinggi_badan;
    private double berat_awal;
    private double target_berat;

    public Member(int id_member, String nama, int umur,
                  double tinggi_badan, double berat_awal,
                  double target_berat, String username, String role) {

        this.id_member = id_member;
        this.nama = nama;
        this.umur = umur;
        this.tinggi_badan = tinggi_badan;
        this.berat_awal = berat_awal;
        this.target_berat = target_berat;

        setUsername(username);
        setRole(role);
    }

    public Member() {

    }

    public int getId_member() {
        return id_member;
    }

    public void setId_member(int id_member) {
        this.id_member = id_member;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public double getTinggi_badan() {
        return tinggi_badan;
    }

    public void setTinggi_badan(double tinggi_badan) {
        this.tinggi_badan = tinggi_badan;
    }

    public double getBerat_awal() {
        return berat_awal;
    }

    public void setBerat_awal(double berat_awal) {
        this.berat_awal = berat_awal;
    }

    public double getTarget_berat() {
        return target_berat;
    }

    public void setTarget_berat(double target_berat) {
        this.target_berat = target_berat;
    }

    @Override
    public String displayRole() {
        return "Member";
    }
    @Override
    public void openDashboard() {
        new DashboardMember(this);
    }
}