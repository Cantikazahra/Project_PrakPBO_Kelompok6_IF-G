/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Users;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */

public class MemberDAO {

    Connection conn;

    public MemberDAO(Connection conn) {
        this.conn = conn;
    }

    public List<Member> getAllMember() {

        List<Member> list = new ArrayList<>();

        try {
            String sql = "SELECT * FROM member";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Member m = new Member(
                        rs.getInt("id_member"),
                        rs.getString("nama"),
                        rs.getInt("umur"),
                        rs.getDouble("tinggi_badan"),
                        rs.getDouble("berat_awal"),
                        rs.getDouble("target_berat"),
                        rs.getString("username"),
                        rs.getString("role")
                );

                list.add(m);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
