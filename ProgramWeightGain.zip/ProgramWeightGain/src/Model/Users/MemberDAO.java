/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Model.Users;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class MemberDAO {

    Connection connection;

    public MemberDAO(Connection connection) {
        this.connection = connection;
    }

    // ===== GET ALL MEMBER =====
    public List<Member> getAllMember() {
        List<Member> list = new ArrayList<>();

        try {
            String query =
                    "SELECT m.*, u.role " +
                    "FROM member m " +
                    "JOIN users u ON m.username = u.username";

            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                Member m = new Member();
                m.setId_member(rs.getInt("id_member"));
                m.setNama(rs.getString("nama"));
                m.setUmur(rs.getInt("umur"));
                m.setTinggi_badan(rs.getDouble("tinggi_badan"));
                m.setBerat_awal(rs.getDouble("berat_awal"));
                m.setTarget_berat(rs.getDouble("target_berat"));
                m.setUsername(rs.getString("username"));
                
                // role diambil dari tabel users
                m.setRole(rs.getString("role"));

                list.add(m);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ===== UPDATE MEMBER =====
    public boolean updateMember(
            int id_member, String nama, int umur, double tinggi, double beratAwal, double targetBerat
    ) {
        try {
            String query =
                    "UPDATE member SET "
                    + "nama=?, "
                    + "umur=?, "
                    + "tinggi_badan=?, "
                    + "berat_awal=?, "
                    + "target_berat=? "
                    + "WHERE id_member=?";

            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, nama);
            ps.setInt(2, umur);
            ps.setDouble(3, tinggi);
            ps.setDouble(4, beratAwal);
            ps.setDouble(5, targetBerat);
            ps.setInt(6, id_member);

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ===== FITUR BARU: DELETE MEMBER =====
    public boolean deleteMember(int id_member) {
        try {
            // Query SQL untuk menghapus data berdasarkan ID Member
            String query = "DELETE FROM member WHERE id_member = ?";
            
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id_member);
            
            // executeUpdate akan mengembalikan jumlah baris yang terpengaruh
            int rowsAffected = ps.executeUpdate();
            
            // Jika rowsAffected > 0, artinya data berhasil dihapus
            return rowsAffected > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}