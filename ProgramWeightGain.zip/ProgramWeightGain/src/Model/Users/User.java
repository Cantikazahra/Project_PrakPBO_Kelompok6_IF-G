/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Users;

/**
 *
 * @author Asus
 */

public abstract class User {

    protected String username;
    protected String password;
    protected String role;

    // ===== GETTER SETTER =====

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // ===== ABSTRACT METHOD =====

    public abstract String displayRole();

    public abstract void openDashboard();
}