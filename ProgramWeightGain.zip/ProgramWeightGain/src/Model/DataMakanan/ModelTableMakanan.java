/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.DataMakanan;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Asus
 */

public class ModelTableMakanan extends AbstractTableModel {

    List<Makanan> listMakanan;

    String[] kolom = {
        "ID",
        "Nama Makanan",
        "Kalori",
        "Protein",
        "Karbohidrat",
        "Lemak"
    };

    public ModelTableMakanan(List<Makanan> listMakanan) {
        this.listMakanan = listMakanan;
    }

    @Override
    public int getRowCount() {
        return listMakanan.size();
    }

    @Override
    public int getColumnCount() {
        return kolom.length;
    }

    @Override
    public String getColumnName(int column) {
        return kolom[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {

        Makanan makanan = listMakanan.get(rowIndex);

        switch (columnIndex) {

            case 0:
                return makanan.getId_makanan();

            case 1:
                return makanan.getNama_makanan();

            case 2:
                return makanan.getKalori();

            case 3:
                return makanan.getProtein();

            case 4:
                return makanan.getKarbohidrat();

            case 5:
                return makanan.getLemak();

            default:
                return null;
        }
    }
}
