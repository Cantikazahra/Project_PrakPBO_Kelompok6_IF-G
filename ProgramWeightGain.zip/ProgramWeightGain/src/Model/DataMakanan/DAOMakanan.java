/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.DataMakanan;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */

public class DAOMakanan implements InterfaceDAOMakanan {

    Connection connection;

    public DAOMakanan() {
        connection = Connector.getConnection();
    }

    @Override
    public void insert(Makanan makanan) {

        try {

            String query =
                    "INSERT INTO makanan "
                    + "(nama_makanan, kalori, protein, karbohidrat, lemak) "
                    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, makanan.getNama_makanan());
            statement.setDouble(2, makanan.getKalori());
            statement.setDouble(3, makanan.getProtein());
            statement.setDouble(4, makanan.getKarbohidrat());
            statement.setDouble(5, makanan.getLemak());

            statement.executeUpdate();

        } catch (Exception e) {
            System.out.println("Insert Gagal : " + e.getMessage());
        }
    }

    @Override
    public void update(Makanan makanan) {

        try {

            String query =
                    "UPDATE makanan SET "
                    + "nama_makanan=?, "
                    + "kalori=?, "
                    + "protein=?, "
                    + "karbohidrat=?, "
                    + "lemak=? "
                    + "WHERE id_makanan=?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, makanan.getNama_makanan());
            statement.setDouble(2, makanan.getKalori());
            statement.setDouble(3, makanan.getProtein());
            statement.setDouble(4, makanan.getKarbohidrat());
            statement.setDouble(5, makanan.getLemak());
            statement.setInt(6, makanan.getId_makanan());

            statement.executeUpdate();

        } catch (Exception e) {
            System.out.println("Update Gagal : " + e.getMessage());
        }
    }

    @Override
    public void delete(int id) {

        try {

            String query =
                    "DELETE FROM makanan WHERE id_makanan=?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setInt(1, id);

            statement.executeUpdate();

        } catch (Exception e) {
            System.out.println("Delete Gagal : " + e.getMessage());
        }
    }

    @Override
    public List<Makanan> getAll() {

        List<Makanan> list = new ArrayList<>();

        try {

            String query = "SELECT * FROM makanan";

            Statement statement =
                    connection.createStatement();

            ResultSet rs =
                    statement.executeQuery(query);

            while (rs.next()) {

                Makanan makanan = new Makanan();

                makanan.setId_makanan(
                        rs.getInt("id_makanan"));

                makanan.setNama_makanan(
                        rs.getString("nama_makanan"));

                makanan.setKalori(
                        rs.getDouble("kalori"));

                makanan.setProtein(
                        rs.getDouble("protein"));

                makanan.setKarbohidrat(
                        rs.getDouble("karbohidrat"));

                makanan.setLemak(
                        rs.getDouble("lemak"));

                list.add(makanan);
            }

        } catch (Exception e) {
            System.out.println("Get All Gagal : " + e.getMessage());
        }

        return list;
    }

    @Override
    public List<Makanan> search(String keyword) {

        List<Makanan> list = new ArrayList<>();

        try {

            String query =
                    "SELECT * FROM makanan "
                    + "WHERE nama_makanan LIKE ?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, "%" + keyword + "%");

            ResultSet rs = statement.executeQuery();

            while (rs.next()) {

                Makanan makanan = new Makanan();

                makanan.setId_makanan(
                        rs.getInt("id_makanan"));

                makanan.setNama_makanan(
                        rs.getString("nama_makanan"));

                makanan.setKalori(
                        rs.getDouble("kalori"));

                makanan.setProtein(
                        rs.getDouble("protein"));

                makanan.setKarbohidrat(
                        rs.getDouble("karbohidrat"));

                makanan.setLemak(
                        rs.getDouble("lemak"));

                list.add(makanan);
            }

        } catch (Exception e) {
            System.out.println("Search Gagal : " + e.getMessage());
        }

        return list;
    }
}
