/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.DataMakanan;
import java.util.List;

/**
 *
 * @author Asus
 */

public interface InterfaceDAOMakanan {

    public void insert(Makanan makanan);

    public void update(Makanan makanan);

    public void delete(int id);

    public List<Makanan> getAll();

    public List<Makanan> search(String keyword);
}
