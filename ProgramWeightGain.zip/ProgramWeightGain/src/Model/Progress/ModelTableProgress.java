/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Progress;

import java.util.List;
import javax.swing.table.AbstractTableModel;


/**
 *
 * @author Asus
 */

public class ModelTableProgress extends AbstractTableModel {

    List<ProgressBerat> listProgress;

    String[] kolom = {
        "ID Progress",
        "ID Member",
        "Tanggal",
        "Berat",
        "Kalori",
        "Catatan"
    };

    public ModelTableProgress(
            List<ProgressBerat> listProgress) {

        this.listProgress = listProgress;
    }

    @Override
    public int getRowCount() {
        return listProgress.size();
    }

    @Override
    public int getColumnCount() {
        return kolom.length;
    }

    @Override
    public String getColumnName(int column) {
        return kolom[column];
    }

    @Override
    public Object getValueAt(
            int rowIndex,
            int columnIndex) {

        ProgressBerat progress =
                listProgress.get(rowIndex);

        switch (columnIndex) {

            case 0:
                return progress.getId_progress();

            case 1:
                return progress.getId_member();

            case 2:
                return progress.getTanggal();

            case 3:
                return progress.getBerat_sekarang();

            case 4:
                return progress.getTotal_kalori_hari_ini();

            case 5:
                return progress.getCatatan();

            default:
                return null;
        }
    }
}
