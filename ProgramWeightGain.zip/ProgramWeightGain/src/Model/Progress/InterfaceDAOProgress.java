/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Progress;
import java.util.List;

/**
 *
 * @author Asus
 */

public interface InterfaceDAOProgress {

    public void insert(ProgressBerat progress);

    public void update(ProgressBerat progress);

    public void delete(int id);

    public List<ProgressBerat> getAll();
}
