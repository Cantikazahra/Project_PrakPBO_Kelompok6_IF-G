package Model.Progress;
import java.util.List;

public interface InterfaceDAOProgress {

    public void insert(ProgressBerat progress);
    public void update(ProgressBerat progress);
    public void delete(int id);
    public List<ProgressBerat> getAll();
    public List<ProgressBerat> getByMember(int id_member);
}
