/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Progress;
import java.util.Date;

/**
 *
 * @author Asus
 */

public class ProgressBerat {

    private int id_progress;
    private int id_member;
    private Date tanggal;
    private double berat_sekarang;
    private double total_kalori_hari_ini;
    private String catatan;

    public int getId_progress() {
        return id_progress;
    }

    public void setId_progress(int id_progress) {
        this.id_progress = id_progress;
    }

    public int getId_member() {
        return id_member;
    }

    public void setId_member(int id_member) {
        this.id_member = id_member;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public double getBerat_sekarang() {
        return berat_sekarang;
    }

    public void setBerat_sekarang(double berat_sekarang) {
        this.berat_sekarang = berat_sekarang;
    }

    public double getTotal_kalori_hari_ini() {
        return total_kalori_hari_ini;
    }

    public void setTotal_kalori_hari_ini(double total_kalori_hari_ini) {
        this.total_kalori_hari_ini = total_kalori_hari_ini;
    }

    public String getCatatan() {
        return catatan;
    }

    public void setCatatan(String catatan) {
        this.catatan = catatan;
    }
}