/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Progress;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class DAOProgress implements InterfaceDAOProgress {

    Connection connection;

    public DAOProgress() {
        connection = Connector.getConnection();
    }

    @Override
    public void insert(ProgressBerat progress) {
        try {
            String query =
                    "INSERT INTO progress "
                    + "(id_member, tanggal, berat_sekarang, "
                    + "total_kalori_hari_ini, catatan) "
                    + "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, progress.getId_member());
            statement.setDate(2, new java.sql.Date(progress.getTanggal().getTime()));
            statement.setDouble(3, progress.getBerat_sekarang());
            statement.setDouble(4, progress.getTotal_kalori_hari_ini());
            statement.setString(5, progress.getCatatan());
            statement.executeUpdate();
        } catch (Exception e) {
            System.out.println("Insert Progress Gagal : " + e.getMessage());
        }
    }

    @Override
    public void update(ProgressBerat progress) {
        try {
            String query =
                    "UPDATE progress SET "
                    + "tanggal=?, berat_sekarang=?, total_kalori_hari_ini=?, catatan=? "
                    + "WHERE id_progress=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setDate(1, new java.sql.Date(progress.getTanggal().getTime()));
            statement.setDouble(2, progress.getBerat_sekarang());
            statement.setDouble(3, progress.getTotal_kalori_hari_ini());
            statement.setString(4, progress.getCatatan());
            statement.setInt(5, progress.getId_progress());
            statement.executeUpdate();
        } catch (Exception e) {
            System.out.println("Update Progress Gagal : " + e.getMessage());
        }
    }

    @Override
    public void delete(int id) {
        try {
            String query = "DELETE FROM progress WHERE id_progress=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (Exception e) {
            System.out.println("Delete Progress Gagal : " + e.getMessage());
        }
    }

    @Override
    public List<ProgressBerat> getAll() {
        List<ProgressBerat> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM progress ORDER BY tanggal DESC";
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (Exception e) {
            System.out.println("Get Progress Gagal : " + e.getMessage());
        }
        return list;
    }

    // ================= GET BY MEMBER =================
    public List<ProgressBerat> getByMember(int id_member) {
        List<ProgressBerat> list = new ArrayList<>();
        try {
            String query =
                    "SELECT * FROM progress WHERE id_member=? ORDER BY tanggal DESC, id_progress DESC";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id_member);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (Exception e) {
            System.out.println("Get Progress By Member Gagal : " + e.getMessage());
        }
        return list;
    }

    private ProgressBerat mapRow(ResultSet rs) throws SQLException {
        ProgressBerat p = new ProgressBerat();
        p.setId_progress(rs.getInt("id_progress"));
        p.setId_member(rs.getInt("id_member"));
        p.setTanggal(rs.getDate("tanggal"));
        p.setBerat_sekarang(rs.getDouble("berat_sekarang"));
        p.setTotal_kalori_hari_ini(rs.getDouble("total_kalori_hari_ini"));
        p.setCatatan(rs.getString("catatan"));
        return p;
    }
}