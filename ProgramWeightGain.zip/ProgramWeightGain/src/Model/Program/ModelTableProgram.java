/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Program;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Asus
 */

public class ModelTableProgram
        extends AbstractTableModel {

    List<ProgramWeightGain> list;

    public ModelTableProgram(
            List<ProgramWeightGain> list
    ) {

        this.list = list;
    }

    String[] kolom = {
        "Kalori",
        "Protein",
        "Karbo",
        "Lemak"
    };

    @Override
    public int getRowCount() {

        return list.size();
    }

    @Override
    public int getColumnCount() {

        return kolom.length;
    }

    @Override
    public String getColumnName(int column) {

        return kolom[column];
    }

    @Override
    public Object getValueAt(
            int rowIndex,
            int columnIndex
    ) {

        ProgramWeightGain p =
                list.get(rowIndex);

        switch (columnIndex) {

            case 0:
                return p.getTargetKalori();

            case 1:
                return p.getProtein();

            case 2:
                return p.getKarbo();

            case 3:
                return p.getLemak();

            default:
                return null;
        }
    }
}