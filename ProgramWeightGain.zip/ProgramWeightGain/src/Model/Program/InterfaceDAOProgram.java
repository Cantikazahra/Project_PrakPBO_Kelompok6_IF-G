/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Program;
import java.util.List;

/**
 *
 * @author Asus
 */

public interface InterfaceDAOProgram {

    public void insert(ProgramWeightGain program);

    public void update(ProgramWeightGain program);

    public void delete(int id_program);

    public List<ProgramWeightGain> getAll();
}
