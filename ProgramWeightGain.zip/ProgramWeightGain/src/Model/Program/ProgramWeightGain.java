/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Program;

/**
 *
 * @author Asus
 */

public class ProgramWeightGain {

    private int id_program;
    private int id_member;

    private double targetKalori;
    private double protein;
    private double karbo;
    private double lemak;

    // CONSTRUCTOR

    public ProgramWeightGain() {
    }

    public ProgramWeightGain(
            int id_member,
            double bmi,
            double targetKalori,
            double protein,
            double karbo,
            double lemak
    ) {

        this.id_member = id_member;
        this.targetKalori = targetKalori;
        this.protein = protein;
        this.karbo = karbo;
        this.lemak = lemak;
    }

    // GETTER SETTER

    public int getId_program() {
        return id_program;
    }

    public void setId_program(int id_program) {
        this.id_program = id_program;
    }

    public int getId_member() {
        return id_member;
    }

    public void setId_member(int id_member) {
        this.id_member = id_member;
    }

    public double getTargetKalori() {
        return targetKalori;
    }

    public void setTargetKalori(double targetKalori) {
        this.targetKalori = targetKalori;
    }

    public double getProtein() {
        return protein;
    }

    public void setProtein(double protein) {
        this.protein = protein;
    }

    public double getKarbo() {
        return karbo;
    }

    public void setKarbo(double karbo) {
        this.karbo = karbo;
    }

    public double getLemak() {
        return lemak;
    }

    public void setLemak(double lemak) {
        this.lemak = lemak;
    }
}
