/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Program;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Asus
 */
public class DAOProgram implements InterfaceDAOProgram {

    Connection conn;

    public DAOProgram() {
        conn = Connector.getConnection();
    }

    @Override
    public void insert(ProgramWeightGain p) {
        try {
            String query =
                    "INSERT INTO program "
                    + "(id_member, target_kalori_harian, "
                    + "target_protein, target_karbohidrat, "
                    + "target_lemak, durasi_bulan) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, p.getId_member());
            stmt.setDouble(2, p.getTargetKalori());
            stmt.setDouble(3, p.getProtein());
            stmt.setDouble(4, p.getKarbo());
            stmt.setDouble(5, p.getLemak());
            stmt.setInt(6, p.getDurasiBulan());
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(ProgramWeightGain p) {
        try {
            String query =
                    "UPDATE program SET "
                    + "target_kalori_harian=?, "
                    + "target_protein=?, "
                    + "target_karbohidrat=?, "
                    + "target_lemak=?, "
                    + "durasi_bulan=? "
                    + "WHERE id_member=?";

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setDouble(1, p.getTargetKalori());
            stmt.setDouble(2, p.getProtein());
            stmt.setDouble(3, p.getKarbo());
            stmt.setDouble(4, p.getLemak());
            stmt.setInt(5, p.getDurasiBulan());
            stmt.setInt(6, p.getId_member());
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id_program) {
        try {
            String query = "DELETE FROM program WHERE id_program=?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, id_program);
            stmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getDurasiProgram(int idMember) {
        try {
            String query = "SELECT durasi_bulan FROM program WHERE id_member=?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idMember);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt("durasi_bulan");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<ProgramWeightGain> getAll() {
        List<ProgramWeightGain> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM program";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                ProgramWeightGain p = new ProgramWeightGain();
                p.setId_program(rs.getInt("id_program"));
                p.setId_member(rs.getInt("id_member"));
                p.setTargetKalori(rs.getDouble("target_kalori_harian"));
                p.setProtein(rs.getDouble("target_protein"));
                p.setKarbo(rs.getDouble("target_karbohidrat"));
                p.setLemak(rs.getDouble("target_lemak"));
                p.setDurasiBulan(rs.getInt("durasi_bulan"));
                list.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
