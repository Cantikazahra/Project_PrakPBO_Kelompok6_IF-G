/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.Program;

import Model.Connector;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */

public class DAOProgram implements InterfaceDAOProgram {

    Connection conn;

    public DAOProgram() {

        conn = Connector.getConnection();
    }

    @Override
    public void insert(ProgramWeightGain p) {

        try {

            String query =
                    "INSERT INTO program "
                    + "(id_member, target_kalori_harian, "
                    + "target_protein, target_karbohidrat, "
                    + "target_lemak, durasi_bulan) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement stmt =
                    conn.prepareStatement(query);

            stmt.setInt(1, p.getId_member());
            stmt.setDouble(2, p.getTargetKalori());
            stmt.setDouble(3, p.getProtein());
            stmt.setDouble(4, p.getKarbo());
            stmt.setDouble(5, p.getLemak());
            stmt.setInt(6, p.getDurasiBulan());

            stmt.executeUpdate();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public int getDurasiProgram(int idMember) {

        try {

            String query =
                    "SELECT durasi_bulan "
                    + "FROM program "
                    + "WHERE id_member=?";

            PreparedStatement stmt =
                    conn.prepareStatement(query);

            stmt.setInt(1, idMember);

            ResultSet rs =
                    stmt.executeQuery();

            if (rs.next()) {

                return rs.getInt("durasi_bulan");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return 0;
    }

    @Override
    public void update(ProgramWeightGain p) {

    }

    @Override
    public void delete(int id_program) {

    }

    @Override
    public List<ProgramWeightGain> getAll() {

        List<ProgramWeightGain> list =
                new ArrayList<>();

        return list;
    }
}