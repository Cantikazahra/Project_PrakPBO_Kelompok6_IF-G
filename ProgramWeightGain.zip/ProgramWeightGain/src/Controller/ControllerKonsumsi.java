/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import Model.Konsumsi.DAOKonsumsi;
import Model.Konsumsi.Konsumsi;
import java.sql.*;

/**
 * @author Asus
 */
public class ControllerKonsumsi {

    private Connection conn;
    private DAOKonsumsi daoKonsumsi;

    public ControllerKonsumsi() {
        conn = Connector.getConnection();
        daoKonsumsi = new DAOKonsumsi();
    }

    public void insertKonsumsi(Konsumsi k) {
        try {
            daoKonsumsi.insert(k);
        } catch (Exception e) {
            System.out.println("Gagal insert konsumsi: " + e.getMessage());
        }
    }

    public double getTotalKalori(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalKalori(id_member, tanggal);
        } catch (Exception e) { return 0; }
    }

    public double getTotalProtein(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalProtein(id_member, tanggal);
        } catch (Exception e) { return 0; }
    }

    public double getTotalKarbo(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalKarbo(id_member, tanggal);
        } catch (Exception e) { return 0; }
    }

    public double getTotalLemak(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalLemak(id_member, tanggal);
        } catch (Exception e) { return 0; }
    }
}
