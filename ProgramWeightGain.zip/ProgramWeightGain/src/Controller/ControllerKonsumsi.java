/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controller;

import Model.Connector;
import Model.Konsumsi.DAOKonsumsi;
import java.sql.*;

/**
 *
 * @author Asus
 */
public class ControllerKonsumsi {

    private Connection conn;
    private DAOKonsumsi daoKonsumsi;

    public ControllerKonsumsi() {
        conn = Connector.getConnection();
        daoKonsumsi = new DAOKonsumsi();
    }

    // Fungsi bawaan asli proyek kamu bray, biarkan tipenya Object agar aman dari konflik package objek
    public void insertKonsumsi(Object k) {
        try {
            daoKonsumsi.getClass().getMethod("insert", k.getClass()).invoke(daoKonsumsi, k);
        } catch (Exception e) {
            try {
                // Alternatif nama fungsi insert data di DAO mu jika bukan 'insert'
                daoKonsumsi.getClass().getMethod("insertKonsumsi", k.getClass()).invoke(daoKonsumsi, k);
            } catch(Exception ex) {
                System.out.println("Gagal panggil method insert di DAO: " + ex.getMessage());
            }
        }
    }

    public double getTotalKalori(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalKalori(id_member, tanggal);
        } catch (Exception e) {
            return 0;
        }
    }

    public double getTotalProtein(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalProtein(id_member, tanggal);
        } catch (Exception e) {
            return 0;
        }
    }

    public double getTotalKarbo(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalKarbo(id_member, tanggal);
        } catch (Exception e) {
            return 0;
        }
    }

    public double getTotalLemak(int id_member, String tanggal) {
        try {
            return daoKonsumsi.getTotalLemak(id_member, tanggal);
        } catch (Exception e) {
            return 0;
        }
    }
}