/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controller;

import Model.Konsumsi.DAOKonsumsi;
import Model.Konsumsi.Konsumsi;
import java.util.List;

/**
 *
 * @author Asus
 */

public class ControllerKonsumsi {

    DAOKonsumsi daoKonsumsi;

    public ControllerKonsumsi() {

        daoKonsumsi =
                new DAOKonsumsi();
    }

    // ================= INSERT =================

    public boolean insertKonsumsi(
            Konsumsi konsumsi) {

        return daoKonsumsi.insert(
                konsumsi);
    }

    // ================= UPDATE =================

    public boolean updateKonsumsi(
            Konsumsi konsumsi) {

        return daoKonsumsi.update(
                konsumsi);
    }

    // ================= DELETE =================

    public boolean deleteKonsumsi(
            int id_konsumsi) {

        return daoKonsumsi.delete(
                id_konsumsi);
    }

    // ================= GET ALL =================

    public List<Konsumsi> getAllKonsumsi() {

        return daoKonsumsi.getAll();
    }

    // ================= GET BY MEMBER =================

    public List<Konsumsi> getKonsumsiMember(
            int id_member) {

        return daoKonsumsi.getByMember(
                id_member);
    }

    // ================= TOTAL KALORI =================

    public double getTotalKaloriHariIni(
            int id_member) {

        return daoKonsumsi
                .getTotalKaloriHariIni(
                        id_member);
    }

    // ================= TOTAL PROTEIN =================

    public double getTotalProteinHariIni(
            int id_member) {

        return daoKonsumsi
                .getTotalProteinHariIni(
                        id_member);
    }

    // ================= TOTAL KARBO =================

    public double getTotalKarboHariIni(
            int id_member) {

        return daoKonsumsi
                .getTotalKarboHariIni(
                        id_member);
    }

    // ================= TOTAL LEMAK =================

    public double getTotalLemakHariIni(
            int id_member) {

        return daoKonsumsi
                .getTotalLemakHariIni(
                        id_member);
    }
}
