/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import Model.Users.Member;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */

public class ControllerMember {

    Connection connection;

    public ControllerMember() {

        connection = Connector.getConnection();
    }

    // ================= INSERT MEMBER =================

    public boolean insertMember(
            String username,
            String nama,
            int umur,
            double tinggi,
            double beratAwal,
            double targetBerat) {

        try {

            String query =
                    "INSERT INTO member "
                    + "(nama, umur, tinggi_badan, berat_awal, target_berat, username, role) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, nama);
            statement.setInt(2, umur);
            statement.setDouble(3, tinggi);
            statement.setDouble(4, beratAwal);
            statement.setDouble(5, targetBerat);
            statement.setString(6, username);
            statement.setString(7, "member");

            statement.executeUpdate();

            return true;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Insert Member Gagal : "
                    + e.getMessage());

            return false;
        }
    }

    // ================= AMBIL DATA MEMBER =================

    public Member getDataMember(String username) {

        try {

            String query =
                    "SELECT * FROM member WHERE username = ?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, username);

            ResultSet rs =
                    statement.executeQuery();

            if (rs.next()) {

                Member member = new Member();
                
                member.setId_member(
                        rs.getInt("id_member"));

                member.setNama(
                        rs.getString("nama"));

                member.setUmur(
                        rs.getInt("umur"));

                member.setTinggi_badan(
                        rs.getDouble("tinggi_badan"));

                member.setBerat_awal(
                        rs.getDouble("berat_awal"));

                member.setTarget_berat(
                        rs.getDouble("target_berat"));

                return member;
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Gagal mengambil data member : "
                    + e.getMessage());
        }

        return null;
    }
}