/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import Model.Users.Member;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */

public class ControllerMember {

    Connection connection;

    public ControllerMember() {

        connection = Connector.getConnection();
    }

    // ================= INSERT MEMBER =================

    public boolean insertMember(
            String username,
            String nama,
            int umur,
            double tinggi,
            double beratAwal,
            double targetBerat) {

        try {

            String query =
                    "INSERT INTO member "
                    + "(username, nama, role, umur, tinggi_badan, berat_awal, target_berat,) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, username);
            statement.setString(2, nama);
            statement.setString(3, "member");
            statement.setInt(4, umur);
            statement.setDouble(5, tinggi);
            statement.setDouble(6, beratAwal);
            statement.setDouble(7, targetBerat);

            statement.executeUpdate();

            return true;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Insert Member Gagal : "
                    + e.getMessage());

            return false;
        }
    }

    // ================= AMBIL DATA MEMBER =================

    public Member getDataMember(String username) {

        try {

            String query =
                    "SELECT * FROM member WHERE username = ?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, username);

            ResultSet rs =
                    statement.executeQuery();

            if (rs.next()) {

                Member member = new Member();
                
                member.setId_member(
                        rs.getInt("id_member"));

                member.setNama(
                        rs.getString("nama"));

                member.setUmur(
                        rs.getInt("umur"));

                member.setTinggi_badan(
                        rs.getDouble("tinggi_badan"));

                member.setBerat_awal(
                        rs.getDouble("berat_awal"));

                member.setTarget_berat(
                        rs.getDouble("target_berat"));

                return member;
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Gagal mengambil data member : "
                    + e.getMessage());
        }

        return null;
    }
}