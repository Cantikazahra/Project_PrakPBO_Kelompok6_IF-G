/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import Model.Users.Member;
import Model.Users.MemberDAO;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
public class ControllerMember {

    Connection connection;
    MemberDAO memberDAO;

    public ControllerMember() {
        connection = Connector.getConnection();
        memberDAO = new MemberDAO(connection);
    }

    // ===== INSERT MEMBER =====
    public boolean insertMember(
            String username, String nama, int umur, double tinggi, double beratAwal, double targetBerat
    ) {
        try {
            // AMBIL ID USER DARI TABEL USERS
            String qUser = "SELECT id_user FROM users WHERE username=?";
            PreparedStatement psUser = connection.prepareStatement(qUser);
            psUser.setString(1, username);
            ResultSet rsUser = psUser.executeQuery();

            int idUser = 0;
            if (rsUser.next()) {
                idUser = rsUser.getInt("id_user");
            }

            // INSERT KE TABEL MEMBER
            String query = "INSERT INTO member "
                    + "(id_user, nama, umur, tinggi_badan, "
                    + "berat_awal, target_berat, username) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, idUser);
            ps.setString(2, nama);
            ps.setInt(3, umur);
            ps.setDouble(4, tinggi);
            ps.setDouble(5, beratAwal);
            ps.setDouble(6, targetBerat);
            ps.setString(7, username);

            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Insert Member Gagal : " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // ===== UPDATE MEMBER =====
    public boolean updateMember(
            int id_member, String nama, int umur, double tinggi, double beratAwal, double targetBerat
    ) {
        boolean ok = memberDAO.updateMember(id_member, nama, umur, tinggi, beratAwal, targetBerat);

        if (!ok) {
            JOptionPane.showMessageDialog(null, "Gagal update data member!");
        }

        return ok;
    }

    // ===== TAMBAHAN: DELETE MEMBER =====
    public boolean deleteMember(int id_member) {
        // Meneruskan perintah hapus ke MemberDAO
        boolean ok = memberDAO.deleteMember(id_member);

        if (!ok) {
            JOptionPane.showMessageDialog(null, "Gagal menghapus data member dari database!");
        }

        return ok;
    }

    // ===== GET DATA MEMBER =====
    public Member getDataMember(String username) {
        try {
            String query = "SELECT m.*, u.role "
                    + "FROM member m "
                    + "JOIN users u "
                    + "ON m.id_user = u.id_user "
                    + "WHERE m.username = ?";

            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Member m = new Member();
                m.setId_member(rs.getInt("id_member"));
                m.setNama(rs.getString("nama"));
                m.setUmur(rs.getInt("umur"));
                m.setTinggi_badan(rs.getDouble("tinggi_badan"));
                m.setBerat_awal(rs.getDouble("berat_awal"));
                m.setTarget_berat(rs.getDouble("target_berat"));
                m.setUsername(rs.getString("username"));
                
                // ROLE DARI TABEL USERS
                m.setRole(rs.getString("role"));

                return m;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal mengambil data member : " + e.getMessage());
            e.printStackTrace();
        }

        return null;
    }
}