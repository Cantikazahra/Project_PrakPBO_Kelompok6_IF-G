/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */

public class ControllerRegister {

    Connection connection;

    public ControllerRegister() {
        connection = Connector.getConnection();
    }

    public boolean register(String username, String password, String role) {

        try {

            // 1. CEK USERNAME SUDAH ADA ATAU BELUM
            String checkQuery = "SELECT username FROM users WHERE username = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setString(1, username);

            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Username sudah digunakan!");
                return false;
            }

            // 2. JIKA BELUM ADA → INSERT
            String query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);

            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, role);

            statement.executeUpdate();

            return true;

        } catch (SQLException e) {

            // fallback kalau masih ada error DB lain
            JOptionPane.showMessageDialog(null,
                    "Register Gagal: " + e.getMessage());

            return false;
        }
    }
}