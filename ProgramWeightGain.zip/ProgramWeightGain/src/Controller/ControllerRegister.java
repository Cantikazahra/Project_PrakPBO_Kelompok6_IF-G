/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;

import View.Login.LoginView;
import View.Login.RegisterView;
import View.Member.InputDataMember;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */

public class ControllerRegister {

    Connection connection;

    public ControllerRegister() {
        connection = Connector.getConnection();
    }

    public ControllerRegister(RegisterView view) {

        connection = Connector.getConnection();

        // ===== BUTTON REGISTER =====
        view.btnRegister.addActionListener(e -> {

            String username = view.getUsername();
            String password = view.getPassword();
            String role     = view.getRole();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Isi semua field!");
                return;
            }

            boolean sukses = register(username, password, role);

            if (sukses) {
                JOptionPane.showMessageDialog(null, "Register berhasil!");
                view.dispose();

                // ===== MEMBER → langsung isi data member =====
                if (role.equalsIgnoreCase("member")) {
                    new InputDataMember(username);
                }

                // ===== ADMIN → kembali ke login =====
                else {
                    LoginView lv = new LoginView();
                    new ControllerLogin(lv);
                }
            }
        });

        // ===== BUTTON BACK =====
        view.btnBack.addActionListener(e -> {
            LoginView lv = new LoginView();
            new ControllerLogin(lv);
            view.dispose();
        });
    }

    public boolean register(String username, String password, String role) {

        try {
            // Cek username sudah ada
            String checkQuery = "SELECT username FROM users WHERE username = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Username sudah digunakan!");
                return false;
            }

            // Insert ke tabel users
            String query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setString(3, role);
            statement.executeUpdate();

            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Register gagal: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
