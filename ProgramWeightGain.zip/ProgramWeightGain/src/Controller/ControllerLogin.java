/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import Model.Users.Admin;
import Model.Users.Member;
import Model.Users.User;

import View.Login.LoginView;
import View.Login.RegisterView;
import View.Member.InputDataMember;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

/**
 * @author Asus
 */
public class ControllerLogin {

    Connection connection;

    public ControllerLogin() {
        connection = Connector.getConnection();
    }

    public ControllerLogin(LoginView view) {

        connection = Connector.getConnection();

        view.btnLogin.addActionListener(e -> {

            String username = view.getUsername();
            String password = view.getPassword();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Isi semua field!");
                return;
            }

            if (!akunAda(username, password)) {
                JOptionPane.showMessageDialog(null,
                        "Akun belum terdaftar!\nSilakan register terlebih dahulu.");
                new RegisterView();
                view.dispose();
                return;
            }

            User user = login(username, password);

            if (user == null) return;

            JOptionPane.showMessageDialog(null, "Login berhasil sebagai " + user.displayRole());
            user.openDashboard();
            view.dispose();
        });

        view.btnRegister.addActionListener(e -> {
            new RegisterView();
            view.dispose();
        });
    }

    private boolean akunAda(String username, String password) {
        try {
            String hashedPassword = ControllerRegister.hashMD5(password);
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, hashedPassword);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public User login(String username, String password) {
        try {
            String hashedPassword = ControllerRegister.hashMD5(password);
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, hashedPassword);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");

                if (role.equalsIgnoreCase("admin")) {
                    Admin admin = new Admin();
                    admin.setUsername(username);
                    return admin;
                } else if (role.equalsIgnoreCase("member")) {
                    ControllerMember cm = new ControllerMember();
                    Member member = cm.getDataMember(username);

                    if (member == null) {
                        JOptionPane.showMessageDialog(null,
                                "Silakan lengkapi data member terlebih dahulu!");
                        new InputDataMember(username);
                        return null;
                    }

                    return member;
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Login: " + e.getMessage());
            e.printStackTrace();
        }

        return null;
    }
}
