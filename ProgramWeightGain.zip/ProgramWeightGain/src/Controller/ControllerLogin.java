/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Asus
 */

public class ControllerLogin {

    Connection connection;

    public ControllerLogin() {
        connection = Connector.getConnection();
    }

    public String login(String username, String password) {

        try {

            String query =
                    "SELECT * FROM users "
                    + "WHERE username=? "
                    + "AND password=?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet rs =
                    statement.executeQuery();

            if (rs.next()) {

                return rs.getString("role");
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Login Gagal : " + e.getMessage());
        }

        return null;
    }
}
