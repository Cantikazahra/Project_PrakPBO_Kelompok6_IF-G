/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Asus
 */

public class ControllerProgress {

    Connection conn;

    public ControllerProgress() {
        conn = Connector.getConnection();
    }

    // ================= INSERT PROGRESS =================
    public boolean insertProgress(
            int id_member,
            String tanggal,
            double berat_sekarang,
            double total_kalori_hari_ini,
            String catatan
    ) {

        try {

            String sql =
                    "INSERT INTO progress "
                    + "(id_member, tanggal, berat_sekarang, total_kalori_hari_ini, catatan) "
                    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(1, id_member);
            ps.setString(2, tanggal);
            ps.setDouble(3, berat_sekarang);
            ps.setDouble(4, total_kalori_hari_ini);
            ps.setString(5, catatan);

            ps.executeUpdate();

            return true;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Gagal simpan progress: " + e.getMessage()
            );

            e.printStackTrace();

            return false;
        }
    }
}
