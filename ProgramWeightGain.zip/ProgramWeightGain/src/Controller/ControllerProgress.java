/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import Model.Progress.DAOProgress;
import Model.Progress.ProgressBerat;
import java.sql.*;
import java.util.List;
import javax.swing.JOptionPane;
/**
 *
 * @author Asus
 */

public class ControllerProgress {

    Connection conn;
    DAOProgress daoProgress;

    public ControllerProgress() {
        conn = Connector.getConnection();
        daoProgress = new DAOProgress();
    }

    public boolean insertProgress(
            int id_member,
            String tanggal,
            double berat_sekarang,
            double total_kalori_hari_ini,
            String catatan) {

        PreparedStatement ps = null;
        try {
            String sql =
                    "INSERT INTO progress "
                    + "(id_member, tanggal, berat_sekarang, total_kalori_hari_ini, catatan) "
                    + "VALUES (?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id_member);
            ps.setString(2, tanggal);
            ps.setDouble(3, berat_sekarang);
            ps.setDouble(4, total_kalori_hari_ini);
            ps.setString(5, catatan);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal simpan progress: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }

    public double getBeratTerakhir(int id_member) {
        try {
            String sql =
                    "SELECT berat_sekarang FROM progress "
                    + "WHERE id_member = ? "
                    + "ORDER BY tanggal DESC, id_progress DESC LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id_member);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble("berat_sekarang");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<ProgressBerat> getProgressMember(int id_member) {
        return daoProgress.getByMember(id_member);
    }
}