/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import View.Dashboard.DashboardMember;
import View.Program.ViewProgram;
import View.Progress.ViewProgress;
import Model.Users.Member;

/**
 *
 * @author Asus
 */

public class ControllerProgram {

    public ControllerProgram(ViewProgram view, Member member) {

        view.btnLanjut.addActionListener(e -> {
            new ViewProgress(member);
            view.dispose();
        });

        view.btnBack.addActionListener(e -> {
            new DashboardMember(member);
            view.dispose();
        });
    }
}