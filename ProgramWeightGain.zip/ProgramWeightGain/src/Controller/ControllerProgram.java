/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import View.Program.ViewProgram;
import View.Dashboard.DashboardMember;

import Model.Users.Member;

import Model.Program.ProgramWeightGain;
import Model.Program.DAOProgram;

import javax.swing.*;

/**
 *
 * @author Asus
 */

public class ControllerProgram {

    ViewProgram view;

    // DATA MEMBER LOGIN
    Member member;

    // DAO PROGRAM
    DAOProgram daoProgram;

    public ControllerProgram(
            ViewProgram view,
            Member member
    ) {

        this.view = view;

        this.member = member;

        daoProgram = new DAOProgram();

        // ================= BUTTON HITUNG =================

        view.getBtnHitung().addActionListener(e -> {

            try {

                double kalori =
                        Double.parseDouble(
                                view.getTfKalori().getText()
                        );

                // ================= PERHITUNGAN =================

                double protein =
                        (kalori * 0.30) / 4;

                double karbo =
                        (kalori * 0.50) / 4;

                double lemak =
                        (kalori * 0.20) / 9;

                // ================= TAMPILKAN HASIL =================

                view.getTfProtein().setText(
                        String.format("%.1f", protein)
                );

                view.getTfKarbo().setText(
                        String.format("%.1f", karbo)
                );

                view.getTfLemak().setText(
                        String.format("%.1f", lemak)
                );

                JOptionPane.showMessageDialog(
                        null,
                        "Program berhasil dihitung!"
                );

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Kalori harus berupa angka!"
                );
            }
        });

        // ================= BUTTON SIMPAN =================

        view.getBtnSimpan().addActionListener(e -> {

            try {

                // VALIDASI INPUT
                if (view.getTfKalori().getText().isEmpty()
                        || view.getTfProtein().getText().isEmpty()
                        || view.getTfKarbo().getText().isEmpty()
                        || view.getTfLemak().getText().isEmpty()) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Semua data harus diisi!"
                    );

                    return;
                }

                // ================= OBJECT PROGRAM =================

                ProgramWeightGain program =
                        new ProgramWeightGain();

                // AMBIL DATA MEMBER LOGIN
                program.setId_member(
                        member.getId_member()
                );

                // AMBIL DATA HASIL PERHITUNGAN
                program.setTargetKalori(
                        Double.parseDouble(
                                view.getTfKalori().getText().replace(",", ".")
                        )
                );

                program.setProtein(
                        Double.parseDouble(
                                view.getTfProtein().getText().replace(",", ".")
                        )
                );

                program.setKarbo(
                        Double.parseDouble(
                                view.getTfKarbo().getText().replace(",", ".")
                        )
                );

                program.setLemak(
                        Double.parseDouble(
                                view.getTfLemak().getText().replace(",", ".")
                        )
                );

                // ================= SIMPAN DATABASE =================

                daoProgram.insert(program);

                JOptionPane.showMessageDialog(
                        null,
                        "Program berhasil disimpan!"
                );

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        null,
                        "Gagal menyimpan data!"
                );

                ex.printStackTrace();
            }
        });

        // ================= BUTTON BACK =================

        view.getBtnBack().addActionListener(e -> {

            new DashboardMember(member);

            view.dispose();

        });
    }
}