/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Connector;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Asus
 */

public class ControllerMakanan {

    Connection connection;

    public ControllerMakanan() {

        connection =
                Connector.getConnection();
    }

    public boolean insertMakanan(
            String nama,
            double kalori,
            double protein,
            double karbo,
            double lemak) {

        try {

            String query =
                    "INSERT INTO makanan "
                    + "(nama_makanan, kalori, "
                    + "protein, karbohidrat, lemak) "
                    + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, nama);
            statement.setDouble(2, kalori);
            statement.setDouble(3, protein);
            statement.setDouble(4, karbo);
            statement.setDouble(5, lemak);
            statement.executeUpdate();

            return true;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Insert Makanan Gagal : "
                    + e.getMessage());

            return false;
        }
    }

    public boolean updateMakanan(
            int id,
            String nama,
            double kalori,
            double protein,
            double karbo,
            double lemak) {

        try {

            String query =
                    "UPDATE makanan SET "
                    + "nama_makanan=?, "
                    + "kalori=?, "
                    + "protein=?, "
                    + "karbohidrat=?, "
                    + "lemak=? "
                    + "WHERE id_makanan=?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, nama);
            statement.setDouble(2, kalori);
            statement.setDouble(3, protein);
            statement.setDouble(4, karbo);
            statement.setDouble(5, lemak);
            statement.setInt(6, id);
            statement.executeUpdate();

            return true;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Update Gagal : "
                    + e.getMessage());

            return false;
        }
    }

    public boolean deleteMakanan(int id) {

        try {

            String query =
                    "DELETE FROM makanan "
                    + "WHERE id_makanan=?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setInt(1, id);

            statement.executeUpdate();

            return true;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Delete Gagal : "
                    + e.getMessage());

            return false;
        }
    }

    public ResultSet cariMakanan(
            String nama) {

        try {

            String query =
                    "SELECT * FROM makanan "
                    + "WHERE nama_makanan=?";

            PreparedStatement statement =
                    connection.prepareStatement(query);

            statement.setString(1, nama);

            return statement.executeQuery();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Cari Makanan Gagal : "
                    + e.getMessage());

            return null;
        }
    }
}