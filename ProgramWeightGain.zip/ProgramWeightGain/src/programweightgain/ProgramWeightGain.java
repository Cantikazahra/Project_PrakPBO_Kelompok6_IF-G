/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programweightgain;
import Controller.ControllerLogin;
import View.Login.LoginView;

/**
 *
 * @author Asus
 */
public class ProgramWeightGain {

    public static void main(String[] args) {
        LoginView view = new LoginView();
        new ControllerLogin(view);  
    }
}
